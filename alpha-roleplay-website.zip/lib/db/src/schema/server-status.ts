import { pgTable, serial, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";

export const serverStatusTable = pgTable("server_status", {
  id: serial("id").primaryKey(),
  isVisible: boolean("is_visible").notNull().default(true),
  isOnline: boolean("is_online").notNull().default(true),
  playersOnline: integer("players_online").notNull().default(0),
  maxPlayers: integer("max_players").notNull().default(64),
  serverName: text("server_name").notNull().default("Alpha Roleplay"),
  message: text("message"),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export type ServerStatus = typeof serverStatusTable.$inferSelect;
