import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";

export const housesTable = pgTable("houses", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  location: text("location").notNull(),
  price: text("price").notNull(),
  capacity: integer("capacity").notNull(),
  imageUrl: text("image_url"),
  description: text("description").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type House = typeof housesTable.$inferSelect;
