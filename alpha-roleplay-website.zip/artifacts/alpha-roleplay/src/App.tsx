import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { MusicPlayer } from "@/components/MusicPlayer";

import Home from "@/pages/public/home";
import Rules from "@/pages/public/rules";
import Announcements from "@/pages/public/announcements";
import Reports from "@/pages/public/reports";
import VIPCars from "@/pages/public/cars";
import UltraVIPCars from "@/pages/public/ultra-vip-cars";
import Houses from "@/pages/public/houses";
import Jobs from "@/pages/public/jobs";

import AdminLogin from "@/pages/admin/login";
import AdminDashboard from "@/pages/admin/dashboard";
import AdminRules from "@/pages/admin/rules";
import AdminAnnouncements from "@/pages/admin/announcements";
import AdminReports from "@/pages/admin/reports";
import AdminCars from "@/pages/admin/cars";
import AdminHouses from "@/pages/admin/houses";
import AdminJobs from "@/pages/admin/jobs";
import AdminServerStatus from "@/pages/admin/server-status";

import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/rregullat" component={Rules} />
      <Route path="/njoftime" component={Announcements} />
      <Route path="/raportime" component={Reports} />
      <Route path="/makina-vip">{() => <VIPCars />}</Route>
      <Route path="/makina-ultra-vip" component={UltraVIPCars} />
      <Route path="/shtepi" component={Houses} />
      <Route path="/pune" component={Jobs} />

      <Route path="/admin/login" component={AdminLogin} />
      <Route path="/admin" component={AdminDashboard} />
      <Route path="/admin/rregullat" component={AdminRules} />
      <Route path="/admin/njoftime" component={AdminAnnouncements} />
      <Route path="/admin/raportime" component={AdminReports} />
      <Route path="/admin/makina" component={AdminCars} />
      <Route path="/admin/shtepi" component={AdminHouses} />
      <Route path="/admin/pune" component={AdminJobs} />
      <Route path="/admin/server" component={AdminServerStatus} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <MusicPlayer />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
