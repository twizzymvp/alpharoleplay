import { PageLayout } from "@/components/layout/PageLayout";
import { useSubmitReport } from "@workspace/api-client-react";
import { Loader2, FlagTriangleRight } from "lucide-react";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";

const reportSchema = z.object({
  name: z.string().min(2, "Emri duhet të ketë të paktën 2 karaktere"),
  serverId: z.string().min(1, "ID është e detyrueshme"),
  description: z.string().min(10, "Përshkrimi duhet të jetë më i gjatë"),
});

type ReportFormValues = z.infer<typeof reportSchema>;

export default function Reports() {
  const { toast } = useToast();
  
  const form = useForm<ReportFormValues>({
    resolver: zodResolver(reportSchema),
    defaultValues: {
      name: "",
      serverId: "",
      description: "",
    },
  });

  const submitMutation = useSubmitReport({
    mutation: {
      onSuccess: () => {
        toast({
          title: "Sukses!",
          description: "Raporti u dërgua! Adminat do ta shqyrtojnë.",
        });
        form.reset();
      },
      onError: () => {
        toast({
          title: "Gabim",
          description: "Pati një problem gjatë dërgimit. Provoni përsëri.",
          variant: "destructive"
        });
      }
    }
  });

  const onSubmit = (data: ReportFormValues) => {
    submitMutation.mutate({ data });
  };

  return (
    <PageLayout>
      <div className="container mx-auto px-4 py-12 md:py-20 max-w-2xl">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center justify-center p-4 bg-primary/10 rounded-full mb-6">
            <FlagTriangleRight className="h-10 w-10 text-primary" />
          </div>
          <h1 className="text-4xl md:text-5xl font-black uppercase italic tracking-tighter mb-4">
            Raporto <span className="text-primary">Lojtar</span>
          </h1>
          <p className="text-lg text-muted-foreground">
            Plotësoni formën e mëposhtme për të raportuar një thyerje rregullash apo problem. 
            Raportimet e rreme ndëshkohen.
          </p>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-card border border-white/10 rounded-2xl p-6 md:p-10 shadow-xl"
        >
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="uppercase text-xs font-bold text-muted-foreground tracking-wider">Emri juaj në lojë</FormLabel>
                      <FormControl>
                        <Input placeholder="psh. John_Doe" className="bg-background/50 h-12" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="serverId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="uppercase text-xs font-bold text-muted-foreground tracking-wider">ID juaj në server</FormLabel>
                      <FormControl>
                        <Input placeholder="psh. 123" className="bg-background/50 h-12" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="uppercase text-xs font-bold text-muted-foreground tracking-wider">Përshkrimi i problemit / Raportit</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Përshkruani me detaje çfarë ndodhi. Përfshini ID-të e lojtarëve të tjerë nëse i keni." 
                        className="min-h-[150px] bg-background/50 resize-y" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button 
                type="submit" 
                size="lg" 
                className="w-full h-14 text-lg font-bold uppercase tracking-wider"
                disabled={submitMutation.isPending}
              >
                {submitMutation.isPending ? (
                  <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> Po Dërgohet...</>
                ) : (
                  "Dërgo Raportin"
                )}
              </Button>
            </form>
          </Form>
        </motion.div>
      </div>
    </PageLayout>
  );
}
