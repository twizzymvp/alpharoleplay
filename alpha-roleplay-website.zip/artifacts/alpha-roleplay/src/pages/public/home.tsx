import { PageLayout } from "@/components/layout/PageLayout";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { useListAnnouncements, getListAnnouncementsQueryKey } from "@workspace/api-client-react";
import { format } from "date-fns";
import { ChevronRight, ArrowRight } from "lucide-react";
import { ServerStatusWidget } from "@/components/ServerStatusWidget";

export default function Home() {
  const { data: announcements, isLoading } = useListAnnouncements({
    query: { queryKey: getListAnnouncementsQueryKey() }
  });

  const recentAnnouncements = announcements?.slice(0, 3) || [];

  return (
    <PageLayout>
      {/* Hero Section */}
      <section className="relative h-[80vh] min-h-[600px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="/images/hero-bg.png" 
            alt="Alpha Roleplay City" 
            className="w-full h-full object-cover object-center opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
          <div className="absolute inset-0 bg-background/20" />
        </div>

        <div className="container relative z-10 mx-auto px-4 text-center flex flex-col items-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <motion.img
              src="/images/logo.webp"
              alt="Alpha Roleplay"
              initial={{ opacity: 0, scale: 0.6 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1.2, ease: "easeOut" }}
              className="mx-auto mb-6 h-32 md:h-40 w-auto object-contain drop-shadow-[0_0_40px_rgba(239,68,68,0.55)]"
            />
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-black tracking-tighter uppercase italic text-white drop-shadow-2xl">
              <span className="glitch-effect" data-text="ALPHA">ALPHA</span>
              <span className="text-primary ml-4">ROLEPLAY</span>
            </h1>
            <p className="mt-6 text-xl md:text-2xl text-gray-300 max-w-2xl mx-auto font-medium tracking-wide">
              Komuniteti më elitar i roleplay në shqip. Fillo historinë tënde sot.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/rregullat" className="inline-block">
                <Button size="lg" className="text-lg px-8 py-6 h-auto font-bold uppercase tracking-wider w-full sm:w-auto shadow-[0_0_20px_rgba(168,85,247,0.4)]">
                  Lexo Rregullat
                </Button>
              </Link>
              <Link href="/njoftime" className="inline-block">
                <Button size="lg" variant="outline" className="text-lg px-8 py-6 h-auto font-bold uppercase tracking-wider w-full sm:w-auto border-white/20 hover:bg-white/10">
                  Njoftimet e Fundit
                </Button>
              </Link>
            </div>
            <ServerStatusWidget />
          </motion.div>
        </div>
      </section>

      {/* Quick Links Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { title: "Makina VIP", desc: "Koleksioni i makinave luksoze", href: "/makina-vip", color: "from-blue-600/20 to-blue-900/20" },
              { title: "Ultra VIP", desc: "Makinat më të rralla në qytet", href: "/makina-ultra-vip", color: "from-purple-600/20 to-purple-900/20" },
              { title: "Shtëpi Familje", desc: "Baza për bandën/familjen tënde", href: "/shtepi", color: "from-green-600/20 to-green-900/20" },
              { title: "Punë", desc: "Biznese dhe vende pune", href: "/pune", color: "from-orange-600/20 to-orange-900/20" }
            ].map((card, i) => (
              <motion.div
                key={card.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                viewport={{ once: true }}
              >
                <Link href={card.href}>
                  <div className={`h-full group relative overflow-hidden rounded-xl border border-white/10 bg-gradient-to-br ${card.color} p-8 hover:border-primary/50 transition-all duration-300`}>
                    <div className="absolute inset-0 bg-black/40 group-hover:bg-transparent transition-colors duration-300" />
                    <div className="relative z-10">
                      <h3 className="text-2xl font-bold uppercase tracking-tight mb-2 group-hover:text-primary transition-colors">{card.title}</h3>
                      <p className="text-muted-foreground">{card.desc}</p>
                      <div className="mt-6 flex items-center text-sm font-bold uppercase tracking-wider text-primary opacity-0 -translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300">
                        Shiko <ArrowRight className="ml-2 h-4 w-4" />
                      </div>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Recent Announcements */}
      <section className="py-20 bg-card border-t border-white/5">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-12">
            <h2 className="text-3xl font-black uppercase italic tracking-tighter">Njoftimet e Fundit</h2>
            <Link href="/njoftime" className="text-primary hover:text-white transition-colors flex items-center font-medium uppercase tracking-wide text-sm">
              Të gjitha <ChevronRight className="ml-1 h-4 w-4" />
            </Link>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-64 rounded-xl bg-white/5 animate-pulse" />
              ))}
            </div>
          ) : recentAnnouncements.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {recentAnnouncements.map((announcement) => (
                <Link key={announcement.id} href={`/njoftime`}>
                  <div className="group h-full rounded-xl border border-white/10 bg-background overflow-hidden hover:border-primary/50 transition-colors">
                    {announcement.imageUrl && (
                      <div className="h-48 w-full overflow-hidden">
                        <img 
                          src={announcement.imageUrl} 
                          alt={announcement.title} 
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                      </div>
                    )}
                    <div className="p-6">
                      <div className="text-xs text-muted-foreground mb-3 font-mono">
                        {format(new Date(announcement.createdAt), "dd/MM/yyyy")}
                      </div>
                      <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors line-clamp-2">
                        {announcement.title}
                      </h3>
                      <p className="text-muted-foreground line-clamp-3 text-sm">
                        {announcement.content}
                      </p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground border border-white/5 rounded-xl bg-background/50">
              Nuk ka njoftime të fundit.
            </div>
          )}
        </div>
      </section>
    </PageLayout>
  );
}
