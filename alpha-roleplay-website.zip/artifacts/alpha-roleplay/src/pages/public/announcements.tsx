import { PageLayout } from "@/components/layout/PageLayout";
import { useListAnnouncements, getListAnnouncementsQueryKey } from "@workspace/api-client-react";
import { Loader2, Bell, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";

export default function Announcements() {
  const { data: announcements, isLoading } = useListAnnouncements({
    query: { queryKey: getListAnnouncementsQueryKey() }
  });

  return (
    <PageLayout>
      <div className="container mx-auto px-4 py-12 md:py-20 max-w-5xl">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center justify-center p-4 bg-primary/10 rounded-full mb-6">
            <Bell className="h-10 w-10 text-primary" />
          </div>
          <h1 className="text-4xl md:text-6xl font-black uppercase italic tracking-tighter mb-4">
            <span className="text-primary">Njoftime</span> Zyrtare
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Qëndroni të përditësuar me lajmet, përditësimet dhe eventet më të fundit në Alpha Roleplay.
          </p>
        </motion.div>

        {isLoading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="h-10 w-10 animate-spin text-primary" />
          </div>
        ) : announcements && announcements.length > 0 ? (
          <div className="space-y-8">
            {announcements.map((announcement, idx) => (
              <motion.div 
                key={announcement.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className={`bg-card rounded-2xl border overflow-hidden ${
                  announcement.important ? 'border-destructive/50 shadow-[0_0_15px_rgba(220,38,38,0.15)]' : 'border-white/10'
                }`}
              >
                <div className="flex flex-col md:flex-row">
                  {announcement.imageUrl && (
                    <div className="md:w-1/3 h-48 md:h-auto shrink-0">
                      <img 
                        src={announcement.imageUrl} 
                        alt={announcement.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                  <div className="p-6 md:p-8 flex-1 flex flex-col justify-center">
                    <div className="flex flex-wrap items-center gap-3 mb-4">
                      <span className="text-sm font-mono text-muted-foreground bg-white/5 px-3 py-1 rounded-md">
                        {format(new Date(announcement.createdAt), "dd/MM/yyyy HH:mm")}
                      </span>
                      {announcement.important && (
                        <Badge variant="destructive" className="uppercase font-bold tracking-wider text-xs px-3 py-1 flex items-center gap-1">
                          <AlertCircle className="h-3 w-3" />
                          E Rëndësishme
                        </Badge>
                      )}
                    </div>
                    <h2 className="text-2xl md:text-3xl font-bold mb-4">{announcement.title}</h2>
                    <div className="text-muted-foreground whitespace-pre-wrap">
                      {announcement.content}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 border border-white/5 rounded-xl bg-card">
            <p className="text-muted-foreground">Nuk ka njoftime për momentin.</p>
          </div>
        )}
      </div>
    </PageLayout>
  );
}
