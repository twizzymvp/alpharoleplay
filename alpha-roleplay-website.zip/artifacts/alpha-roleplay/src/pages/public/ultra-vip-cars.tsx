import VIPCars from "./cars";

export default function UltraVIPCars() {
  return <VIPCars tier="ultra_vip" title="Makina Ultra VIP" />;
}