import { PageLayout } from "@/components/layout/PageLayout";
import { useListHouses, getListHousesQueryKey, useBuyHouse } from "@workspace/api-client-react";
import { Loader2, Home, MapPin, Users, Key, MessageSquare } from "lucide-react";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useState } from "react";

const purchaseSchema = z.object({
  buyerName: z.string().min(2, "Emri duhet të ketë të paktën 2 karaktere"),
  contact: z.string().optional(),
  notes: z.string().optional(),
});

type PurchaseFormValues = z.infer<typeof purchaseSchema>;

export default function Houses() {
  const { toast } = useToast();
  const [openDialogId, setOpenDialogId] = useState<number | null>(null);

  const { data: houses, isLoading } = useListHouses({
    query: { queryKey: getListHousesQueryKey() }
  });

  const buyMutation = useBuyHouse({
    mutation: {
      onSuccess: () => {
        toast({
          title: "Blerja u dërgua!",
          description: "Pas blerjes, të lutem hap një ticket në Discord që adminat të finalizojnë porosinë.",
        });
        setOpenDialogId(null);
      },
      onError: () => {
        toast({ title: "Gabim", description: "Pati një problem gjatë dërgimit.", variant: "destructive" });
      }
    }
  });

  const PurchaseForm = ({ houseId }: { houseId: number }) => {
    const form = useForm<PurchaseFormValues>({
      resolver: zodResolver(purchaseSchema),
      defaultValues: { buyerName: "", contact: "", notes: "" },
    });

    const onSubmit = (data: PurchaseFormValues) => {
      buyMutation.mutate({
        id: houseId,
        data: {
          buyerName: data.buyerName,
          serverId: "—",
          contact: data.contact,
          notes: data.notes,
        },
      });
    };

    return (
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField control={form.control} name="buyerName" render={({ field }) => (
            <FormItem><FormLabel>Emri / Familja juaj</FormLabel><FormControl><Input placeholder="p.sh. Familja Hoxha" {...field} /></FormControl><FormMessage /></FormItem>
          )} />
          <FormField control={form.control} name="contact" render={({ field }) => (
            <FormItem><FormLabel>Discord (username)</FormLabel><FormControl><Input placeholder="emri#0000 ose @emri" {...field} /></FormControl><FormMessage /></FormItem>
          )} />
          <FormField control={form.control} name="notes" render={({ field }) => (
            <FormItem><FormLabel>Detaje shtesë (opsionale)</FormLabel><FormControl><Textarea placeholder="Lokacioni i preferuar, modifikime etj." rows={3} {...field} /></FormControl><FormMessage /></FormItem>
          )} />

          <div className="rounded-md border border-[#5865F2]/40 bg-[#5865F2]/10 p-3 text-sm text-white/90 flex gap-2 items-start">
            <MessageSquare className="h-4 w-4 mt-0.5 text-[#a8b3ff] shrink-0" />
            <span>Pas blerjes, të lutem <b>hap një ticket në Discord</b> që adminat të finalizojnë porosinë.</span>
          </div>

          <Button type="submit" className="w-full" disabled={buyMutation.isPending}>
            {buyMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <><Key className="mr-2 h-4 w-4" /> Dërgo Blerjen</>}
          </Button>
        </form>
      </Form>
    );
  };

  return (
    <PageLayout>
      <div className="container mx-auto px-4 py-12 md:py-20">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-16">
          <div className="inline-flex items-center justify-center p-4 bg-primary/10 rounded-full mb-6">
            <Home className="h-10 w-10 text-primary" />
          </div>
          <h1 className="text-4xl md:text-5xl font-black uppercase italic tracking-tighter mb-4">Shtëpi për Familje</h1>
          <p className="text-lg text-muted-foreground">Baza ideale për bandën ose familjen tënde.</p>
        </motion.div>

        {isLoading ? (
          <div className="flex justify-center py-20"><Loader2 className="h-10 w-10 animate-spin text-primary" /></div>
        ) : houses && houses.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {houses.map((house, idx) => (
              <motion.div key={house.id} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: idx * 0.1 }} className="bg-card border border-white/10 rounded-2xl overflow-hidden group">
                <div className="h-48 bg-white/5 relative overflow-hidden flex items-center justify-center">
                  {house.imageUrl ? (
                    <img src={house.imageUrl} alt={house.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                  ) : (
                    <Home className="h-16 w-16 text-white/20" />
                  )}
                  <div className="absolute top-4 right-4 bg-black/80 px-3 py-1 rounded-full text-green-400 font-bold text-sm border border-green-400/20 backdrop-blur-sm">
                    {house.price}
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-2xl font-bold mb-4">{house.name}</h3>
                  <div className="flex gap-4 mb-4 text-sm text-muted-foreground">
                    <div className="flex items-center"><MapPin className="h-4 w-4 mr-1 text-primary" /> {house.location}</div>
                    <div className="flex items-center"><Users className="h-4 w-4 mr-1 text-primary" /> {house.capacity} Vende</div>
                  </div>
                  <p className="text-muted-foreground text-sm mb-6 h-10 line-clamp-2">{house.description}</p>
                  
                  <Dialog open={openDialogId === house.id} onOpenChange={(open) => setOpenDialogId(open ? house.id : null)}>
                    <DialogTrigger asChild>
                      <Button className="w-full font-bold uppercase tracking-wider hover:bg-green-600 hover:text-white transition-colors border-green-600/50">
                        <Key className="mr-2 h-4 w-4" /> Blej
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[425px]">
                      <DialogHeader>
                        <DialogTitle>Blerje: {house.name}</DialogTitle>
                        <DialogDescription>Blerja realizohet nga adminat në Discord — nuk paguani këtu.</DialogDescription>
                      </DialogHeader>
                      <PurchaseForm houseId={house.id} />
                    </DialogContent>
                  </Dialog>
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 border border-white/5 rounded-xl bg-card"><p className="text-muted-foreground">Asnjë shtëpi e disponueshme.</p></div>
        )}
      </div>
    </PageLayout>
  );
}
