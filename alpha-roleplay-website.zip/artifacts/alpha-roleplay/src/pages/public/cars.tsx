import { PageLayout } from "@/components/layout/PageLayout";
import { useListCars, getListCarsQueryKey, useBuyCar } from "@workspace/api-client-react";
import { Loader2, Car, ShoppingCart, MessageSquare } from "lucide-react";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useState } from "react";

const purchaseSchema = z.object({
  buyerName: z.string().min(2, "Emri duhet të ketë të paktën 2 karaktere"),
  contact: z.string().optional(),
  notes: z.string().optional(),
});

type PurchaseFormValues = z.infer<typeof purchaseSchema>;

export default function VIPCars({ tier = "vip", title = "Makina VIP" }: { tier?: "vip" | "ultra_vip", title?: string }) {
  const { toast } = useToast();
  const [openDialogId, setOpenDialogId] = useState<number | null>(null);

  const { data: cars, isLoading } = useListCars(
    { tier },
    { query: { queryKey: getListCarsQueryKey({ tier }) } }
  );

  const buyMutation = useBuyCar({
    mutation: {
      onSuccess: () => {
        toast({
          title: "Blerja u dërgua!",
          description: "Pas blerjes, të lutem hap një ticket në Discord që adminat të finalizojnë porosinë.",
        });
        setOpenDialogId(null);
      },
      onError: () => {
        toast({
          title: "Gabim",
          description: "Pati një problem gjatë dërgimit. Provoni përsëri.",
          variant: "destructive"
        });
      }
    }
  });

  const PurchaseForm = ({ carId }: { carId: number }) => {
    const form = useForm<PurchaseFormValues>({
      resolver: zodResolver(purchaseSchema),
      defaultValues: { buyerName: "", contact: "", notes: "" },
    });

    const onSubmit = (data: PurchaseFormValues) => {
      buyMutation.mutate({
        id: carId,
        data: {
          buyerName: data.buyerName,
          serverId: "—",
          contact: data.contact,
          notes: data.notes,
        },
      });
    };

    return (
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField control={form.control} name="buyerName" render={({ field }) => (
            <FormItem><FormLabel>Emri / Familja juaj</FormLabel><FormControl><Input placeholder="p.sh. Familja Hoxha" {...field} /></FormControl><FormMessage /></FormItem>
          )} />
          <FormField control={form.control} name="contact" render={({ field }) => (
            <FormItem><FormLabel>Discord (username)</FormLabel><FormControl><Input placeholder="emri#0000 ose @emri" {...field} /></FormControl><FormMessage /></FormItem>
          )} />
          <FormField control={form.control} name="notes" render={({ field }) => (
            <FormItem><FormLabel>Detaje shtesë (opsionale)</FormLabel><FormControl><Textarea placeholder="Ngjyra, modifikimet, koha kur preferoni etj." rows={3} {...field} /></FormControl><FormMessage /></FormItem>
          )} />

          <div className="rounded-md border border-[#5865F2]/40 bg-[#5865F2]/10 p-3 text-sm text-white/90 flex gap-2 items-start">
            <MessageSquare className="h-4 w-4 mt-0.5 text-[#a8b3ff] shrink-0" />
            <span>Pas blerjes, të lutem <b>hap një ticket në Discord</b> që adminat të finalizojnë porosinë.</span>
          </div>

          <Button type="submit" className="w-full" disabled={buyMutation.isPending}>
            {buyMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <><ShoppingCart className="mr-2 h-4 w-4" /> Dërgo Blerjen</>}
          </Button>
        </form>
      </Form>
    );
  };

  return (
    <PageLayout>
      <div className="container mx-auto px-4 py-12 md:py-20">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-16">
          <div className="inline-flex items-center justify-center p-4 bg-primary/10 rounded-full mb-6">
            <Car className="h-10 w-10 text-primary" />
          </div>
          <h1 className="text-4xl md:text-5xl font-black uppercase italic tracking-tighter mb-4">{title}</h1>
          <p className="text-lg text-muted-foreground">Makinat më ekskluzive në Alpha Roleplay.</p>
        </motion.div>

        {isLoading ? (
          <div className="flex justify-center py-20"><Loader2 className="h-10 w-10 animate-spin text-primary" /></div>
        ) : cars && cars.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {cars.map((car, idx) => (
              <motion.div key={car.id} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: idx * 0.1 }} className="bg-card border border-white/10 rounded-2xl overflow-hidden group">
                <div className="h-56 bg-white/5 relative overflow-hidden flex items-center justify-center">
                  {car.imageUrl ? (
                    <img src={car.imageUrl} alt={car.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                  ) : (
                    <Car className="h-16 w-16 text-white/20" />
                  )}
                  <div className="absolute top-4 right-4 bg-black/80 px-3 py-1 rounded-full text-primary font-bold text-sm border border-primary/20 backdrop-blur-sm">
                    {car.price}
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-2xl font-bold mb-2">{car.name}</h3>
                  <p className="text-muted-foreground text-sm mb-6 h-10 line-clamp-2">{car.description}</p>
                  
                  <Dialog open={openDialogId === car.id} onOpenChange={(open) => setOpenDialogId(open ? car.id : null)}>
                    <DialogTrigger asChild>
                      <Button className="w-full font-bold uppercase tracking-wider group-hover:shadow-[0_0_15px_rgba(168,85,247,0.4)] transition-shadow">
                        <ShoppingCart className="mr-2 h-4 w-4" /> Blej
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[425px]">
                      <DialogHeader>
                        <DialogTitle>Kërkesë për Blerje: {car.name}</DialogTitle>
                        <DialogDescription>
                          Blerja realizohet nga adminat në Discord — nuk paguani këtu.
                        </DialogDescription>
                      </DialogHeader>
                      <PurchaseForm carId={car.id} />
                    </DialogContent>
                  </Dialog>
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 border border-white/5 rounded-xl bg-card"><p className="text-muted-foreground">Asnjë makinë në këtë kategori ende.</p></div>
        )}
      </div>
    </PageLayout>
  );
}
