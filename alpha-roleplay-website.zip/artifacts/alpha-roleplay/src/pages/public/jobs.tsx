import { PageLayout } from "@/components/layout/PageLayout";
import { useListJobs, getListJobsQueryKey, useApplyJob } from "@workspace/api-client-react";
import { Loader2, Briefcase, ShoppingCart, MessageSquare } from "lucide-react";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useState } from "react";

const buySchema = z.object({
  buyerName: z.string().min(2, "Emri duhet të ketë të paktën 2 karaktere"),
  contact: z.string().optional(),
  notes: z.string().optional(),
});

type BuyFormValues = z.infer<typeof buySchema>;

export default function Jobs() {
  const { toast } = useToast();
  const [openDialogId, setOpenDialogId] = useState<number | null>(null);

  const { data: jobs, isLoading } = useListJobs({
    query: { queryKey: getListJobsQueryKey() }
  });

  const buyMutation = useApplyJob({
    mutation: {
      onSuccess: () => {
        toast({
          title: "Blerja u dërgua!",
          description: "Pas blerjes, të lutem hap një ticket në Discord që adminat të finalizojnë porosinë.",
        });
        setOpenDialogId(null);
      },
      onError: () => {
        toast({ title: "Gabim", description: "Pati një problem gjatë dërgimit.", variant: "destructive" });
      }
    }
  });

  const BuyForm = ({ jobId }: { jobId: number }) => {
    const form = useForm<BuyFormValues>({
      resolver: zodResolver(buySchema),
      defaultValues: { buyerName: "", contact: "", notes: "" },
    });

    const onSubmit = (data: BuyFormValues) => {
      buyMutation.mutate({
        id: jobId,
        data: {
          buyerName: data.buyerName,
          serverId: "—",
          contact: data.contact,
          notes: data.notes,
        },
      });
    };

    return (
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField control={form.control} name="buyerName" render={({ field }) => (
            <FormItem><FormLabel>Emri / Familja juaj</FormLabel><FormControl><Input placeholder="p.sh. Familja Hoxha" {...field} /></FormControl><FormMessage /></FormItem>
          )} />
          <FormField control={form.control} name="contact" render={({ field }) => (
            <FormItem><FormLabel>Discord (username)</FormLabel><FormControl><Input placeholder="emri#0000 ose @emri" {...field} /></FormControl><FormMessage /></FormItem>
          )} />
          <FormField control={form.control} name="notes" render={({ field }) => (
            <FormItem><FormLabel>Çfarë dëshironi (detaje)</FormLabel><FormControl><Textarea placeholder="Shkruani gjithçka që ju duhet, p.sh. lloji i armëve, sasia, koha kur preferoni etj." rows={4} {...field} /></FormControl><FormMessage /></FormItem>
          )} />

          <div className="rounded-md border border-[#5865F2]/40 bg-[#5865F2]/10 p-3 text-sm text-white/90 flex gap-2 items-start">
            <MessageSquare className="h-4 w-4 mt-0.5 text-[#a8b3ff] shrink-0" />
            <span>Pas blerjes, të lutem <b>hap një ticket në Discord</b> që adminat të finalizojnë porosinë.</span>
          </div>

          <Button type="submit" className="w-full" disabled={buyMutation.isPending}>
            {buyMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <><ShoppingCart className="mr-2 h-4 w-4" /> Dërgo Blerjen</>}
          </Button>
        </form>
      </Form>
    );
  };

  return (
    <PageLayout>
      <div className="container mx-auto px-4 py-12 md:py-20">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-16">
          <div className="inline-flex items-center justify-center p-4 bg-primary/10 rounded-full mb-6">
            <Briefcase className="h-10 w-10 text-primary" />
          </div>
          <h1 className="text-4xl md:text-5xl font-black uppercase italic tracking-tighter mb-4">Punë për Familje</h1>
          <p className="text-lg text-muted-foreground">Familja juaj ka nevojë për një punë që të ketë jetë në server — armë, plumba, mekanik etj. Bli direkt nga këtu.</p>
        </motion.div>

        {isLoading ? (
          <div className="flex justify-center py-20"><Loader2 className="h-10 w-10 animate-spin text-primary" /></div>
        ) : jobs && jobs.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {jobs.map((job, idx) => (
              <motion.div key={job.id} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: idx * 0.1 }} className="bg-card border border-white/10 rounded-2xl overflow-hidden group">
                <div className="h-48 bg-white/5 relative overflow-hidden flex items-center justify-center">
                  {job.imageUrl ? (
                    <img src={job.imageUrl} alt={job.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                  ) : (
                    <Briefcase className="h-16 w-16 text-white/20" />
                  )}
                  <div className="absolute top-4 right-4 bg-black/80 px-3 py-1 rounded-full text-orange-400 font-bold text-sm border border-orange-400/20 backdrop-blur-sm">
                    {job.price}
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-2xl font-bold mb-2">{job.name}</h3>
                  <p className="text-muted-foreground text-sm mb-4 h-10 line-clamp-2">{job.description}</p>
                  <div className="mb-6 p-3 bg-white/5 rounded-lg border border-white/5">
                    <p className="text-sm font-semibold text-white/80">Përfitimet:</p>
                    <p className="text-sm text-primary mt-1">{job.benefits}</p>
                  </div>
                  
                  <Dialog open={openDialogId === job.id} onOpenChange={(open) => setOpenDialogId(open ? job.id : null)}>
                    <DialogTrigger asChild>
                      <Button className="w-full font-bold uppercase tracking-wider hover:bg-orange-600 hover:text-white transition-colors border-orange-600/50">
                        <ShoppingCart className="mr-2 h-4 w-4" /> Blej
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[425px]">
                      <DialogHeader>
                        <DialogTitle>Blej: {job.name}</DialogTitle>
                        <DialogDescription>Blerja realizohet nga adminat në Discord — nuk paguani këtu.</DialogDescription>
                      </DialogHeader>
                      <BuyForm jobId={job.id} />
                    </DialogContent>
                  </Dialog>
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 border border-white/5 rounded-xl bg-card"><p className="text-muted-foreground">Asnjë punë e disponueshme.</p></div>
        )}
      </div>
    </PageLayout>
  );
}
