import { PageLayout } from "@/components/layout/PageLayout";
import { useListRules, getListRulesQueryKey } from "@workspace/api-client-react";
import { Loader2, ShieldAlert } from "lucide-react";
import { motion } from "framer-motion";

export default function Rules() {
  const { data: rules, isLoading } = useListRules({
    query: { queryKey: getListRulesQueryKey() }
  });

  // Group rules by category
  const groupedRules = rules?.reduce((acc, rule) => {
    if (!acc[rule.category]) {
      acc[rule.category] = [];
    }
    acc[rule.category].push(rule);
    return acc;
  }, {} as Record<string, typeof rules>) || {};

  return (
    <PageLayout>
      <div className="container mx-auto px-4 py-12 md:py-20 max-w-4xl">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center justify-center p-4 bg-primary/10 rounded-full mb-6">
            <ShieldAlert className="h-10 w-10 text-primary" />
          </div>
          <h1 className="text-4xl md:text-6xl font-black uppercase italic tracking-tighter mb-4">
            Rregullat e <span className="text-primary">Serverit</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Leximi dhe zbatimi i këtyre rregullave është i detyrueshëm për të gjithë lojtarët. Mosnjohja e tyre nuk ju përjashton nga ndëshkimi.
          </p>
        </motion.div>

        {isLoading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="h-10 w-10 animate-spin text-primary" />
          </div>
        ) : Object.keys(groupedRules).length > 0 ? (
          <div className="space-y-12">
            {Object.entries(groupedRules).map(([category, categoryRules], idx) => (
              <motion.div 
                key={category}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
              >
                <h2 className="text-2xl font-bold uppercase tracking-wider mb-6 border-b border-white/10 pb-4 text-white">
                  {category}
                </h2>
                <div className="space-y-6">
                  {categoryRules.map((rule, ruleIdx) => (
                    <div key={rule.id} className="bg-card border border-white/5 rounded-xl p-6 hover:border-primary/30 transition-colors">
                      <h3 className="text-xl font-bold mb-3 flex items-start gap-3">
                        <span className="text-primary font-black">{ruleIdx + 1}.</span>
                        {rule.title}
                      </h3>
                      <div className="text-muted-foreground leading-relaxed pl-7 whitespace-pre-wrap">
                        {rule.content}
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 border border-white/5 rounded-xl bg-card">
            <p className="text-muted-foreground">Nuk ka rregulla të publikuara ende.</p>
          </div>
        )}
      </div>
    </PageLayout>
  );
}
