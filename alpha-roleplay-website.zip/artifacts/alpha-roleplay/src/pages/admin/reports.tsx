import { AdminLayout } from "@/components/layout/AdminLayout";
import { AuthGuard } from "@/components/layout/AuthGuard";
import { useListReports, getListReportsQueryKey, useUpdateReport, useDeleteReport, ReportUpdateStatus } from "@workspace/api-client-react";
import { Loader2, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";

export default function AdminReports() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: items, isLoading } = useListReports({ query: { queryKey: getListReportsQueryKey() } });

  const updateMutation = useUpdateReport({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListReportsQueryKey() });
        toast({ title: "Statusi u përditësua" });
      }
    }
  });

  const deleteMutation = useDeleteReport({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListReportsQueryKey() });
        toast({ title: "Raporti u fshi" });
      }
    }
  });

  const handleStatusChange = (id: number, status: ReportUpdateStatus) => {
    updateMutation.mutate({ id, data: { status } });
  };

  const getStatusLabel = (status: string) => {
    switch(status) {
      case "open": return "Hapur";
      case "in_progress": return "Në Shqyrtim";
      case "resolved": return "Zgjidhur";
      case "rejected": return "Refuzuar";
      default: return status;
    }
  };

  const getStatusColor = (status: string) => {
    switch(status) {
      case "open": return "text-red-400";
      case "in_progress": return "text-yellow-400";
      case "resolved": return "text-green-400";
      case "rejected": return "text-muted-foreground";
      default: return "";
    }
  };

  return (
    <AuthGuard>
      <AdminLayout>
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Menaxho Raportimet</h1>
          </div>
        </div>

        <div className="bg-card border border-white/10 rounded-xl overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="border-white/10">
                <TableHead>Data</TableHead>
                <TableHead>Lojtari (ID)</TableHead>
                <TableHead>Përshkrimi</TableHead>
                <TableHead>Statusi</TableHead>
                <TableHead>Veprime</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow><TableCell colSpan={5} className="text-center py-8"><Loader2 className="h-6 w-6 animate-spin mx-auto text-primary" /></TableCell></TableRow>
              ) : items?.length === 0 ? (
                <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">Nuk ka raportime.</TableCell></TableRow>
              ) : items?.map((item) => (
                <TableRow key={item.id} className="border-white/10">
                  <TableCell className="font-medium whitespace-nowrap">{format(new Date(item.createdAt), "dd/MM/yyyy HH:mm")}</TableCell>
                  <TableCell className="whitespace-nowrap">{item.name} ({item.serverId})</TableCell>
                  <TableCell className="max-w-[200px] truncate" title={item.description}>{item.description}</TableCell>
                  <TableCell>
                    <Select defaultValue={item.status} onValueChange={(val) => handleStatusChange(item.id, val as ReportUpdateStatus)}>
                      <SelectTrigger className={`w-[130px] border-white/10 ${getStatusColor(item.status)}`}>
                        <SelectValue placeholder="Statusi" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="open">Hapur</SelectItem>
                        <SelectItem value="in_progress">Në Shqyrtim</SelectItem>
                        <SelectItem value="resolved">Zgjidhur</SelectItem>
                        <SelectItem value="rejected">Refuzuar</SelectItem>
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    <Button variant="destructive" size="icon" onClick={() => { if(confirm("Jeni i sigurt?")) deleteMutation.mutate({ id: item.id }) }} disabled={deleteMutation.isPending}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </AdminLayout>
    </AuthGuard>
  );
}
