import { AdminLayout } from "@/components/layout/AdminLayout";
import { AuthGuard } from "@/components/layout/AuthGuard";
import { useListAnnouncements, getListAnnouncementsQueryKey, useCreateAnnouncement, useUpdateAnnouncement, useDeleteAnnouncement, AnnouncementInput } from "@workspace/api-client-react";
import { Loader2, Plus, Edit, Trash2 } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ImageInput } from "@/components/admin/ImageInput";
import { Switch } from "@/components/ui/switch";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";

const announcementSchema = z.object({
  title: z.string().min(1, "Titulli kërkohet"),
  content: z.string().min(1, "Përmbajtja kërkohet"),
  imageUrl: z.string().optional().or(z.literal("")),
  important: z.boolean(),
});

type AnnouncementFormValues = z.infer<typeof announcementSchema>;

export default function AdminAnnouncements() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [editingItem, setEditingItem] = useState<{ id: number, data: AnnouncementFormValues } | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const { data: items, isLoading } = useListAnnouncements({ query: { queryKey: getListAnnouncementsQueryKey() } });

  const createMutation = useCreateAnnouncement({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAnnouncementsQueryKey() });
        toast({ title: "Njoftimi u shtua" });
        setIsDialogOpen(false);
      }
    }
  });

  const updateMutation = useUpdateAnnouncement({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAnnouncementsQueryKey() });
        toast({ title: "Njoftimi u përditësua" });
        setIsDialogOpen(false);
      }
    }
  });

  const deleteMutation = useDeleteAnnouncement({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAnnouncementsQueryKey() });
        toast({ title: "Njoftimi u fshi" });
      }
    }
  });

  const form = useForm<AnnouncementFormValues>({
    resolver: zodResolver(announcementSchema),
    defaultValues: { title: "", content: "", imageUrl: "", important: false },
  });

  const openCreateDialog = () => {
    setEditingItem(null);
    form.reset({ title: "", content: "", imageUrl: "", important: false });
    setIsDialogOpen(true);
  };

  const openEditDialog = (item: any) => {
    setEditingItem({ id: item.id, data: item });
    form.reset({ title: item.title, content: item.content, imageUrl: item.imageUrl || "", important: item.important });
    setIsDialogOpen(true);
  };

  const onSubmit = (data: AnnouncementFormValues) => {
    // Convert empty string to null for imageUrl
    const submitData = { ...data, imageUrl: data.imageUrl || null };
    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, data: submitData });
    } else {
      createMutation.mutate({ data: submitData });
    }
  };

  return (
    <AuthGuard>
      <AdminLayout>
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Menaxho Njoftimet</h1>
          </div>
          <Button onClick={openCreateDialog}><Plus className="h-4 w-4 mr-2" /> Shto Njoftim</Button>
        </div>

        <div className="bg-card border border-white/10 rounded-xl overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="border-white/10">
                <TableHead>Data</TableHead>
                <TableHead>Titulli</TableHead>
                <TableHead>I Rëndësishëm</TableHead>
                <TableHead>Veprime</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow><TableCell colSpan={4} className="text-center py-8"><Loader2 className="h-6 w-6 animate-spin mx-auto text-primary" /></TableCell></TableRow>
              ) : items?.length === 0 ? (
                <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">Nuk ka njoftime.</TableCell></TableRow>
              ) : items?.map((item) => (
                <TableRow key={item.id} className="border-white/10">
                  <TableCell className="font-medium whitespace-nowrap">{format(new Date(item.createdAt), "dd/MM/yyyy")}</TableCell>
                  <TableCell className="max-w-[300px] truncate">{item.title}</TableCell>
                  <TableCell>{item.important ? <span className="text-destructive font-bold">Po</span> : "Jo"}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="icon" onClick={() => openEditDialog(item)}><Edit className="h-4 w-4" /></Button>
                      <Button variant="destructive" size="icon" onClick={() => { if(confirm("Jeni i sigurt?")) deleteMutation.mutate({ id: item.id }) }} disabled={deleteMutation.isPending}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>{editingItem ? "Ndrysho Njoftimin" : "Shto Njoftim të Ri"}</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField control={form.control} name="title" render={({ field }) => (
                  <FormItem><FormLabel>Titulli</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="content" render={({ field }) => (
                  <FormItem><FormLabel>Përmbajtja</FormLabel><FormControl><Textarea className="min-h-[100px]" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="imageUrl" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Imazhi (Opsional)</FormLabel>
                    <FormControl>
                      <ImageInput value={field.value || ""} onChange={field.onChange} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="important" render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border border-white/10 p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">E Rëndësishme</FormLabel>
                    </div>
                    <FormControl>
                      <Switch checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                  </FormItem>
                )} />
                <Button type="submit" className="w-full" disabled={createMutation.isPending || updateMutation.isPending}>
                  {(createMutation.isPending || updateMutation.isPending) ? <Loader2 className="h-4 w-4 animate-spin" /> : "Ruaj"}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </AdminLayout>
    </AuthGuard>
  );
}
