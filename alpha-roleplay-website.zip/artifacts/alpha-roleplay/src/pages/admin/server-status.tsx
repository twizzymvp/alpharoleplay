import { useEffect, useState } from "react";
import { AuthGuard } from "@/components/layout/AuthGuard";
import { AdminLayout } from "@/components/layout/AdminLayout";
import {
  useGetServerStatus,
  useUpdateServerStatus,
  getGetServerStatusQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Server } from "lucide-react";

export default function AdminServerStatus() {
  return (
    <AuthGuard>
      <AdminServerStatusInner />
    </AuthGuard>
  );
}

function AdminServerStatusInner() {
  const { data, isLoading } = useGetServerStatus();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [form, setForm] = useState({
    isVisible: true,
    isOnline: true,
    playersOnline: 0,
    maxPlayers: 64,
    serverName: "Alpha Roleplay",
    message: "",
  });

  useEffect(() => {
    if (data) {
      setForm({
        isVisible: data.isVisible,
        isOnline: data.isOnline,
        playersOnline: data.playersOnline,
        maxPlayers: data.maxPlayers,
        serverName: data.serverName,
        message: data.message ?? "",
      });
    }
  }, [data]);

  const updateMutation = useUpdateServerStatus({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({
          queryKey: getGetServerStatusQueryKey(),
        });
        toast({
          title: "U ruajt",
          description: "Statusi i serverit u përditësua.",
        });
      },
      onError: () => {
        toast({
          title: "Gabim",
          description: "Nuk u arrit ruajtja.",
          variant: "destructive",
        });
      },
    },
  });

  const handleSave = () => {
    updateMutation.mutate({
      data: {
        isVisible: form.isVisible,
        isOnline: form.isOnline,
        playersOnline: Number(form.playersOnline) || 0,
        maxPlayers: Number(form.maxPlayers) || 64,
        serverName: form.serverName.trim() || "Alpha Roleplay",
        message: form.message.trim() ? form.message.trim() : null,
      },
    });
  };

  return (
    <AdminLayout>
      <div className="mb-8 flex items-center gap-3">
        <Server className="h-8 w-8 text-primary" />
        <div>
          <h1 className="text-3xl font-black uppercase tracking-tight">
            Statusi i Serverit
          </h1>
          <p className="text-muted-foreground">
            Menaxho atë që shihet në faqen kryesore.
          </p>
        </div>
      </div>

      {isLoading ? (
        <div className="h-40 rounded-xl bg-white/5 animate-pulse" />
      ) : (
        <div className="rounded-xl border border-white/10 bg-card p-6 max-w-2xl space-y-6">
          <div className="flex items-center justify-between rounded-lg border border-white/5 p-4">
            <div>
              <Label className="text-base">Shfaqe në faqen kryesore</Label>
              <p className="text-sm text-muted-foreground">
                Nëse fikur, vizitorët nuk e shohin badge-in.
              </p>
            </div>
            <Switch
              checked={form.isVisible}
              onCheckedChange={(v) =>
                setForm((f) => ({ ...f, isVisible: v }))
              }
            />
          </div>

          <div className="flex items-center justify-between rounded-lg border border-white/5 p-4">
            <div>
              <Label className="text-base">Serveri është ONLINE</Label>
              <p className="text-sm text-muted-foreground">
                Tregohet me jeshile/te kuqe.
              </p>
            </div>
            <Switch
              checked={form.isOnline}
              onCheckedChange={(v) =>
                setForm((f) => ({ ...f, isOnline: v }))
              }
            />
          </div>

          <div>
            <Label htmlFor="serverName">Emri i Serverit</Label>
            <Input
              id="serverName"
              value={form.serverName}
              onChange={(e) =>
                setForm((f) => ({ ...f, serverName: e.target.value }))
              }
              className="mt-2"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="playersOnline">Lojtarë Aktualë</Label>
              <Input
                id="playersOnline"
                type="number"
                min={0}
                value={form.playersOnline}
                onChange={(e) =>
                  setForm((f) => ({
                    ...f,
                    playersOnline: Number(e.target.value),
                  }))
                }
                className="mt-2"
              />
            </div>
            <div>
              <Label htmlFor="maxPlayers">Kapaciteti Max</Label>
              <Input
                id="maxPlayers"
                type="number"
                min={1}
                value={form.maxPlayers}
                onChange={(e) =>
                  setForm((f) => ({
                    ...f,
                    maxPlayers: Number(e.target.value),
                  }))
                }
                className="mt-2"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="message">Mesazh (opsional)</Label>
            <Textarea
              id="message"
              value={form.message}
              onChange={(e) =>
                setForm((f) => ({ ...f, message: e.target.value }))
              }
              placeholder="P.sh.: Mirëmbajtje në orën 22:00"
              className="mt-2"
              rows={3}
            />
          </div>

          <Button
            onClick={handleSave}
            disabled={updateMutation.isPending}
            className="w-full font-bold uppercase tracking-wider"
          >
            {updateMutation.isPending ? "Duke ruajtur..." : "Ruaj"}
          </Button>
        </div>
      )}
    </AdminLayout>
  );
}
