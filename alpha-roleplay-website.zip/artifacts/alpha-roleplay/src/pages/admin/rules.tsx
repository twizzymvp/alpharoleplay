import { AdminLayout } from "@/components/layout/AdminLayout";
import { AuthGuard } from "@/components/layout/AuthGuard";
import { useListRules, getListRulesQueryKey, useCreateRule, useUpdateRule, useDeleteRule, RuleInput } from "@workspace/api-client-react";
import { Loader2, Plus, Edit, Trash2 } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

const RULE_CATEGORIES = [
  "Të Përgjithshme",
  "Roleplay (RP)",
  "Familje & Banda",
  "Krime",
  "Policia & Ligji",
  "Trafiku & Makinat",
  "Sjellja & Chat",
  "Discord",
  "Adminat & Stafi",
  "Cheats & Bugs",
] as const;

const ruleSchema = z.object({
  category: z.string().min(1, "Kategoria kërkohet"),
  title: z.string().min(1, "Titulli kërkohet"),
  content: z.string().min(1, "Përmbajtja kërkohet"),
});

type RuleFormValues = z.infer<typeof ruleSchema>;

export default function AdminRules() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [editingRule, setEditingRule] = useState<{ id: number, data: RuleFormValues } | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const { data: rules, isLoading } = useListRules({ query: { queryKey: getListRulesQueryKey() } });

  const createMutation = useCreateRule({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListRulesQueryKey() });
        toast({ title: "Rregulli u shtua" });
        setIsDialogOpen(false);
      }
    }
  });

  const updateMutation = useUpdateRule({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListRulesQueryKey() });
        toast({ title: "Rregulli u përditësua" });
        setIsDialogOpen(false);
      }
    }
  });

  const deleteMutation = useDeleteRule({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListRulesQueryKey() });
        toast({ title: "Rregulli u fshi" });
      }
    }
  });

  const form = useForm<RuleFormValues>({
    resolver: zodResolver(ruleSchema),
    defaultValues: { category: "", title: "", content: "" },
  });

  const openCreateDialog = () => {
    setEditingRule(null);
    form.reset({ category: "", title: "", content: "" });
    setIsDialogOpen(true);
  };

  const openEditDialog = (rule: any) => {
    setEditingRule({ id: rule.id, data: rule });
    form.reset({ category: rule.category, title: rule.title, content: rule.content });
    setIsDialogOpen(true);
  };

  const onSubmit = (data: RuleFormValues) => {
    if (editingRule) {
      updateMutation.mutate({ id: editingRule.id, data });
    } else {
      createMutation.mutate({ data });
    }
  };

  return (
    <AuthGuard>
      <AdminLayout>
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Menaxho Rregullat</h1>
          </div>
          <Button onClick={openCreateDialog}><Plus className="h-4 w-4 mr-2" /> Shto Rregull</Button>
        </div>

        <div className="bg-card border border-white/10 rounded-xl overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="border-white/10">
                <TableHead>Kategoria</TableHead>
                <TableHead>Titulli</TableHead>
                <TableHead>Veprime</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow><TableCell colSpan={3} className="text-center py-8"><Loader2 className="h-6 w-6 animate-spin mx-auto text-primary" /></TableCell></TableRow>
              ) : rules?.length === 0 ? (
                <TableRow><TableCell colSpan={3} className="text-center py-8 text-muted-foreground">Nuk ka rregulla.</TableCell></TableRow>
              ) : rules?.map((rule) => (
                <TableRow key={rule.id} className="border-white/10">
                  <TableCell className="font-medium">{rule.category}</TableCell>
                  <TableCell>{rule.title}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="icon" onClick={() => openEditDialog(rule)}><Edit className="h-4 w-4" /></Button>
                      <Button variant="destructive" size="icon" onClick={() => { if(confirm("Jeni i sigurt?")) deleteMutation.mutate({ id: rule.id }) }} disabled={deleteMutation.isPending}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>{editingRule ? "Ndrysho Rregullin" : "Shto Rregull të Re"}</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField control={form.control} name="category" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Kategoria</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Zgjidh kategorinë..." />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {RULE_CATEGORIES.map((cat) => (
                          <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="title" render={({ field }) => (
                  <FormItem><FormLabel>Titulli</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="content" render={({ field }) => (
                  <FormItem><FormLabel>Përmbajtja</FormLabel><FormControl><Textarea className="min-h-[150px]" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <Button type="submit" className="w-full" disabled={createMutation.isPending || updateMutation.isPending}>
                  {(createMutation.isPending || updateMutation.isPending) ? <Loader2 className="h-4 w-4 animate-spin" /> : "Ruaj"}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </AdminLayout>
    </AuthGuard>
  );
}
