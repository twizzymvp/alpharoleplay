import { AdminLayout } from "@/components/layout/AdminLayout";
import { AuthGuard } from "@/components/layout/AuthGuard";
import { useListJobs, getListJobsQueryKey, useCreateJob, useUpdateJob, useDeleteJob } from "@workspace/api-client-react";
import { Loader2, Plus, Edit, Trash2 } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ImageInput } from "@/components/admin/ImageInput";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

const itemSchema = z.object({
  name: z.string().min(1, "Emri kërkohet"),
  benefits: z.string().min(1, "Përfitimet kërkohen"),
  description: z.string().min(1, "Përshkrimi kërkohet"),
  price: z.string().min(1, "Çmimi kërkohet"),
  imageUrl: z.string().optional().or(z.literal("")),
});

type ItemFormValues = z.infer<typeof itemSchema>;

export default function AdminJobs() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [editingItem, setEditingItem] = useState<{ id: number, data: ItemFormValues } | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const { data: items, isLoading } = useListJobs({ query: { queryKey: getListJobsQueryKey() } });

  const createMutation = useCreateJob({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListJobsQueryKey() });
        toast({ title: "Puna u shtua" });
        setIsDialogOpen(false);
      }
    }
  });

  const updateMutation = useUpdateJob({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListJobsQueryKey() });
        toast({ title: "Puna u përditësua" });
        setIsDialogOpen(false);
      }
    }
  });

  const deleteMutation = useDeleteJob({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListJobsQueryKey() });
        toast({ title: "Puna u fshi" });
      }
    }
  });

  const form = useForm<ItemFormValues>({
    resolver: zodResolver(itemSchema),
    defaultValues: { name: "", benefits: "", description: "", price: "", imageUrl: "" },
  });

  const openCreateDialog = () => {
    setEditingItem(null);
    form.reset({ name: "", benefits: "", description: "", price: "", imageUrl: "" });
    setIsDialogOpen(true);
  };

  const openEditDialog = (item: any) => {
    setEditingItem({ id: item.id, data: item });
    form.reset({ name: item.name, benefits: item.benefits, description: item.description, price: item.price, imageUrl: item.imageUrl || "" });
    setIsDialogOpen(true);
  };

  const onSubmit = (data: ItemFormValues) => {
    const submitData = { ...data, imageUrl: data.imageUrl || null };
    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, data: submitData });
    } else {
      createMutation.mutate({ data: submitData });
    }
  };

  return (
    <AuthGuard>
      <AdminLayout>
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Menaxho Punët</h1>
          </div>
          <Button onClick={openCreateDialog}><Plus className="h-4 w-4 mr-2" /> Shto Punë</Button>
        </div>

        <div className="bg-card border border-white/10 rounded-xl overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="border-white/10">
                <TableHead>Emri</TableHead>
                <TableHead>Çmimi</TableHead>
                <TableHead>Veprime</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow><TableCell colSpan={3} className="text-center py-8"><Loader2 className="h-6 w-6 animate-spin mx-auto text-primary" /></TableCell></TableRow>
              ) : items?.length === 0 ? (
                <TableRow><TableCell colSpan={3} className="text-center py-8 text-muted-foreground">Nuk ka punë.</TableCell></TableRow>
              ) : items?.map((item) => (
                <TableRow key={item.id} className="border-white/10">
                  <TableCell className="font-medium">{item.name}</TableCell>
                  <TableCell>{item.price}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="icon" onClick={() => openEditDialog(item)}><Edit className="h-4 w-4" /></Button>
                      <Button variant="destructive" size="icon" onClick={() => { if(confirm("Jeni i sigurt?")) deleteMutation.mutate({ id: item.id }) }} disabled={deleteMutation.isPending}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>{editingItem ? "Ndrysho Punën" : "Shto Punë të Re"}</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField control={form.control} name="name" render={({ field }) => (
                    <FormItem><FormLabel>Emri</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                  )} />
                  <FormField control={form.control} name="price" render={({ field }) => (
                    <FormItem><FormLabel>Çmimi i Aplikimit</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                  )} />
                </div>
                <FormField control={form.control} name="benefits" render={({ field }) => (
                  <FormItem><FormLabel>Përfitimet</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="description" render={({ field }) => (
                  <FormItem><FormLabel>Përshkrimi</FormLabel><FormControl><Textarea className="min-h-[100px]" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="imageUrl" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Imazhi (Opsional)</FormLabel>
                    <FormControl>
                      <ImageInput value={field.value || ""} onChange={field.onChange} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <Button type="submit" className="w-full" disabled={createMutation.isPending || updateMutation.isPending}>
                  {(createMutation.isPending || updateMutation.isPending) ? <Loader2 className="h-4 w-4 animate-spin" /> : "Ruaj"}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </AdminLayout>
    </AuthGuard>
  );
}
