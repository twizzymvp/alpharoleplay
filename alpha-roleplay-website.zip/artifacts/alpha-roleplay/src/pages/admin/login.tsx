import { useAdminLogin, getGetAuthStatusQueryKey, useGetAuthStatus } from "@workspace/api-client-react";
import { Loader2, Lock } from "lucide-react";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";

const loginSchema = z.object({
  username: z.string().min(1, "Username kërkohet"),
  password: z.string().min(1, "Fjalëkalimi kërkohet"),
});

type LoginFormValues = z.infer<typeof loginSchema>;

export default function AdminLogin() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  const { data: authStatus, isLoading: checkLoading } = useGetAuthStatus({
    query: { queryKey: getGetAuthStatusQueryKey() }
  });

  useEffect(() => {
    if (authStatus?.authenticated) {
      setLocation("/admin");
    }
  }, [authStatus, setLocation]);

  const form = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: { username: "", password: "" },
  });

  const loginMutation = useAdminLogin({
    mutation: {
      onSuccess: () => {
        toast({ title: "Sukses!", description: "Mirësevini në Panel" });
        queryClient.invalidateQueries({ queryKey: getGetAuthStatusQueryKey() });
        setLocation("/admin");
      },
      onError: (err) => {
        toast({ title: "Gabim", description: "Kredenciale të pasakta.", variant: "destructive" });
      }
    }
  });

  const onSubmit = (data: LoginFormValues) => {
    loginMutation.mutate({ data });
  };

  if (checkLoading) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="animate-spin h-10 w-10 text-primary" /></div>;

  return (
    <div className="min-h-screen flex items-center justify-center bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/20 via-background to-background"></div>
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md p-8 bg-card border border-white/10 rounded-2xl shadow-2xl relative z-10 backdrop-blur-sm"
      >
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center p-4 bg-primary/10 rounded-full mb-4">
            <Lock className="h-8 w-8 text-primary" />
          </div>
          <h1 className="text-3xl font-black tracking-tight uppercase">Alpha<span className="text-primary">Admin</span></h1>
          <p className="text-muted-foreground mt-2">Hyrje vetëm për stafin e autorizuar</p>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField control={form.control} name="username" render={({ field }) => (
              <FormItem>
                <FormLabel>Username</FormLabel>
                <FormControl><Input placeholder="admin" className="h-12 bg-background/50" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <FormField control={form.control} name="password" render={({ field }) => (
              <FormItem>
                <FormLabel>Fjalëkalimi</FormLabel>
                <FormControl><Input type="password" placeholder="••••••••" className="h-12 bg-background/50" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <Button type="submit" className="w-full h-12 text-lg font-bold" disabled={loginMutation.isPending}>
              {loginMutation.isPending ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : "Hyr"}
            </Button>
          </form>
        </Form>
      </motion.div>
    </div>
  );
}
