import { AdminLayout } from "@/components/layout/AdminLayout";
import { AuthGuard } from "@/components/layout/AuthGuard";
import { useGetDashboardStats, getGetDashboardStatsQueryKey } from "@workspace/api-client-react";
import { Loader2, FlagTriangleRight, FileText, Bell, Car, Home, Briefcase } from "lucide-react";
import { motion } from "framer-motion";

export default function AdminDashboard() {
  const { data: stats, isLoading } = useGetDashboardStats({
    query: { queryKey: getGetDashboardStatsQueryKey() }
  });

  const statCards = [
    { title: "Raportime të Hapura", value: stats?.openReports || 0, icon: FlagTriangleRight, color: "text-destructive", bg: "bg-destructive/10" },
    { title: "Raportime Totale", value: stats?.reports || 0, icon: FlagTriangleRight, color: "text-blue-400", bg: "bg-blue-400/10" },
    { title: "Njoftime", value: stats?.announcements || 0, icon: Bell, color: "text-primary", bg: "bg-primary/10" },
    { title: "Rregulla", value: stats?.rules || 0, icon: FileText, color: "text-green-400", bg: "bg-green-400/10" },
    { title: "Makina", value: stats?.cars || 0, icon: Car, color: "text-purple-400", bg: "bg-purple-400/10" },
    { title: "Shtëpi", value: stats?.houses || 0, icon: Home, color: "text-orange-400", bg: "bg-orange-400/10" },
    { title: "Punë", value: stats?.jobs || 0, icon: Briefcase, color: "text-yellow-400", bg: "bg-yellow-400/10" },
  ];

  return (
    <AuthGuard>
      <AdminLayout>
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Përmbledhja</h1>
          <p className="text-muted-foreground">Mirësevini në panelin e menaxhimit të Alpha Roleplay.</p>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-20"><Loader2 className="h-10 w-10 animate-spin text-primary" /></div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {statCards.map((card, idx) => {
              const Icon = card.icon;
              return (
                <motion.div 
                  key={card.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="bg-card border border-white/10 rounded-xl p-6"
                >
                  <div className="flex items-center gap-4">
                    <div className={`p-4 rounded-lg ${card.bg}`}>
                      <Icon className={`h-6 w-6 ${card.color}`} />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground font-medium">{card.title}</p>
                      <p className={`text-3xl font-black ${card.title === "Raportime të Hapura" && card.value > 0 ? "text-destructive" : ""}`}>
                        {card.value}
                      </p>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </AdminLayout>
    </AuthGuard>
  );
}
