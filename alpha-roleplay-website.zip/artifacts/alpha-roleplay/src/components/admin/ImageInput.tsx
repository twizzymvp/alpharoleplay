import { useRef, useState } from "react";
import { Upload, Link2, X, Loader2, ImageIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

type Mode = "url" | "upload";

interface Props {
  value: string;
  onChange: (url: string) => void;
  disabled?: boolean;
}

export function ImageInput({ value, onChange, disabled }: Props) {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [mode, setMode] = useState<Mode>(
    value && !value.startsWith("/api/uploads/") ? "url" : "upload",
  );
  const [uploading, setUploading] = useState(false);

  const handleFile = async (file: File) => {
    if (!file.type.startsWith("image/")) {
      toast({
        title: "Skedar i pavlefshëm",
        description: "Vetëm imazhe lejohen.",
        variant: "destructive",
      });
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      toast({
        title: "Skedari shumë i madh",
        description: "Maksimumi 8MB.",
        variant: "destructive",
      });
      return;
    }

    setUploading(true);
    const fd = new FormData();
    fd.append("file", file);

    try {
      const res = await fetch("/api/upload", {
        method: "POST",
        body: fd,
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || "Ngarkimi dështoi");
      }
      const data = (await res.json()) as { url: string };
      onChange(data.url);
      toast({ title: "Imazhi u ngarkua" });
    } catch (e) {
      toast({
        title: "Gabim gjatë ngarkimit",
        description: e instanceof Error ? e.message : "Provoni përsëri.",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex gap-1 p-1 bg-white/5 rounded-md w-fit">
        <button
          type="button"
          onClick={() => setMode("upload")}
          className={`px-3 py-1 text-xs font-medium rounded flex items-center gap-1.5 transition-colors ${
            mode === "upload"
              ? "bg-primary text-white"
              : "text-muted-foreground hover:text-white"
          }`}
        >
          <Upload className="h-3 w-3" /> Ngarko Skedar
        </button>
        <button
          type="button"
          onClick={() => setMode("url")}
          className={`px-3 py-1 text-xs font-medium rounded flex items-center gap-1.5 transition-colors ${
            mode === "url"
              ? "bg-primary text-white"
              : "text-muted-foreground hover:text-white"
          }`}
        >
          <Link2 className="h-3 w-3" /> URL
        </button>
      </div>

      {mode === "url" ? (
        <Input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="https://..."
          disabled={disabled}
        />
      ) : (
        <div className="flex items-center gap-2">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void handleFile(f);
            }}
          />
          <Button
            type="button"
            variant="outline"
            onClick={() => fileInputRef.current?.click()}
            disabled={disabled || uploading}
            className="flex-1"
          >
            {uploading ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Upload className="h-4 w-4 mr-2" />
            )}
            {uploading ? "Duke ngarkuar..." : "Zgjidh imazhin"}
          </Button>
          <span className="text-xs text-muted-foreground">Maks 8MB</span>
        </div>
      )}

      {value ? (
        <div className="relative inline-block group">
          <img
            src={value}
            alt="preview"
            className="h-24 w-auto rounded border border-white/10 object-cover bg-white/5"
            onError={(e) => {
              (e.target as HTMLImageElement).style.display = "none";
            }}
          />
          <button
            type="button"
            onClick={() => onChange("")}
            aria-label="Fshi imazhin"
            className="absolute -top-2 -right-2 h-6 w-6 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <X className="h-3 w-3" />
          </button>
        </div>
      ) : (
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <ImageIcon className="h-3 w-3" /> Asnjë imazh i zgjedhur
        </div>
      )}
    </div>
  );
}
