import { useEffect, useRef, useState } from "react";
import { Play, Pause, Volume2, VolumeX, X, Music, SkipForward } from "lucide-react";

const PLAYLIST = ["tALK9QKqP5I", "JlI6E4AQQrI", "Trh2hDoSWgY"] as const;

const STORAGE_KEY = "alpha_music_state_v2";

interface YTPlayer {
  playVideo: () => void;
  pauseVideo: () => void;
  mute: () => void;
  unMute: () => void;
  setVolume: (v: number) => void;
  nextVideo: () => void;
  destroy: () => void;
  getPlayerState: () => number;
}

declare global {
  interface Window {
    YT: {
      Player: new (
        el: HTMLElement | string,
        config: Record<string, unknown>,
      ) => YTPlayer;
      PlayerState: { ENDED: number; PLAYING: number; PAUSED: number };
    };
    onYouTubeIframeAPIReady?: () => void;
  }
}

let ytApiPromise: Promise<void> | null = null;

function loadYouTubeAPI(): Promise<void> {
  if (typeof window === "undefined") return Promise.resolve();
  if (window.YT && window.YT.Player) return Promise.resolve();
  if (ytApiPromise) return ytApiPromise;

  ytApiPromise = new Promise<void>((resolve) => {
    const previous = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = () => {
      previous?.();
      resolve();
    };
    const tag = document.createElement("script");
    tag.src = "https://www.youtube.com/iframe_api";
    document.head.appendChild(tag);
  });
  return ytApiPromise;
}

type MusicState = {
  enabled: boolean;
  muted: boolean;
  closed: boolean;
};

const defaultState: MusicState = {
  enabled: true,
  muted: true,
  closed: false,
};

function loadState(): MusicState {
  if (typeof window === "undefined") return defaultState;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultState;
    const parsed = JSON.parse(raw);
    return { ...defaultState, ...parsed };
  } catch {
    return defaultState;
  }
}

function saveState(s: MusicState) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
  } catch {
    /* ignore */
  }
}

export function MusicPlayer() {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const playerRef = useRef<YTPlayer | null>(null);
  const [state, setState] = useState<MusicState>(defaultState);
  const VOLUME_KEY = "alpha_music_volume_v2";
  const [volume, setVolume] = useState<number>(() => {
    if (typeof window === "undefined") return 40;
    const v = Number(window.localStorage.getItem(VOLUME_KEY));
    return Number.isFinite(v) && v >= 0 && v <= 100 ? v : 40;
  });
  const [hydrated, setHydrated] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setState(loadState());
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated || state.closed) return;
    let cancelled = false;

    loadYouTubeAPI().then(() => {
      if (cancelled) return;
      if (!containerRef.current) return;
      if (playerRef.current) return;

      playerRef.current = new window.YT.Player(containerRef.current, {
        height: "0",
        width: "0",
        videoId: PLAYLIST[0],
        playerVars: {
          autoplay: 1,
          controls: 0,
          disablekb: 1,
          fs: 0,
          modestbranding: 1,
          playsinline: 1,
          rel: 0,
          loop: 1,
          playlist: PLAYLIST.join(","),
        },
        events: {
          onReady: (e: { target: YTPlayer }) => {
            const p = e.target;
            p.setVolume(volume);
            if (state.muted) p.mute();
            else p.unMute();
            if (state.enabled) p.playVideo();
            else p.pauseVideo();
            setReady(true);
          },
          onStateChange: (e: { data: number; target: YTPlayer }) => {
            if (e.data === window.YT.PlayerState.ENDED) {
              e.target.nextVideo();
            }
          },
        },
      });
    });

    return () => {
      cancelled = true;
    };
  }, [hydrated, state.closed]);

  useEffect(() => {
    if (!ready || !playerRef.current) return;
    const p = playerRef.current;
    p.setVolume(volume);
    if (state.muted) p.mute();
    else p.unMute();
    if (state.enabled) p.playVideo();
    else p.pauseVideo();
    saveState(state);
    try {
      window.localStorage.setItem(VOLUME_KEY, String(volume));
    } catch {
      /* ignore */
    }
  }, [state, volume, ready]);

  if (!hydrated) return null;

  if (state.closed) {
    return (
      <button
        type="button"
        aria-label="Hap kontrollin e muzikës"
        onClick={() =>
          setState({ closed: false, enabled: true, muted: false })
        }
        className="fixed bottom-4 right-4 z-50 h-12 w-12 rounded-full bg-primary text-white shadow-[0_0_20px_rgba(168,85,247,0.5)] hover:scale-110 transition-transform flex items-center justify-center"
      >
        <Music className="h-5 w-5" />
      </button>
    );
  }

  return (
    <>
      {/* Hidden YouTube iframe host */}
      <div
        aria-hidden
        style={{
          position: "fixed",
          left: -9999,
          top: -9999,
          width: 0,
          height: 0,
          overflow: "hidden",
          pointerEvents: "none",
        }}
      >
        <div ref={containerRef} />
      </div>

      <div className="fixed bottom-4 right-4 z-50 flex items-center gap-2 rounded-full border border-white/15 bg-black/85 backdrop-blur-md px-3 py-2 shadow-[0_0_30px_rgba(168,85,247,0.25)]">
        <div className="hidden sm:flex items-center gap-2 pr-1 pl-1 text-xs uppercase tracking-wider text-white/70">
          <Music className="h-4 w-4 text-primary" />
          <span>Muzika</span>
        </div>

        <button
          type="button"
          onClick={() => setState((s) => ({ ...s, enabled: !s.enabled }))}
          aria-label={state.enabled ? "Ndalo muzikën" : "Lësho muzikën"}
          className="h-9 w-9 rounded-full bg-primary/20 hover:bg-primary/40 text-white flex items-center justify-center transition-colors"
        >
          {state.enabled ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
        </button>

        <button
          type="button"
          onClick={() => setState((s) => ({ ...s, muted: !s.muted }))}
          aria-label={state.muted ? "Aktivizo zërin" : "Heshtni zërin"}
          className="h-9 w-9 rounded-full bg-white/5 hover:bg-white/15 text-white flex items-center justify-center transition-colors"
        >
          {state.muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
        </button>

        <button
          type="button"
          onClick={() => playerRef.current?.nextVideo()}
          aria-label="Kënga tjetër"
          className="h-9 w-9 rounded-full bg-white/5 hover:bg-white/15 text-white flex items-center justify-center transition-colors"
          disabled={!ready}
        >
          <SkipForward className="h-4 w-4" />
        </button>

        <input
          type="range"
          min={0}
          max={100}
          step={1}
          value={volume}
          onChange={(e) => {
            const v = Number(e.target.value);
            setVolume(v);
            setState((s) => ({
              ...s,
              muted: v === 0,
              enabled: v > 0 ? true : s.enabled,
            }));
          }}
          aria-label="Volumi"
          className="w-20 sm:w-24 accent-primary cursor-pointer"
        />

        <button
          type="button"
          onClick={() =>
            setState((s) => ({ ...s, enabled: false, closed: true }))
          }
          aria-label="Mbylle muzikën"
          className="h-9 w-9 rounded-full bg-white/5 hover:bg-red-500/30 text-white flex items-center justify-center transition-colors"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </>
  );
}
