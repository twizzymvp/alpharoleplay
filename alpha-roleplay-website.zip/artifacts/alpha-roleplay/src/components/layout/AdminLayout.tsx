import { Link, useLocation } from "wouter";
import { useAdminLogout } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { 
  LayoutDashboard, 
  BookOpen, 
  Bell, 
  FlagTriangleRight, 
  CarFront, 
  Home, 
  Briefcase,
  Server,
  LogOut,
  Menu,
  X
} from "lucide-react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { getGetAuthStatusQueryKey } from "@workspace/api-client-react";

export function AdminLayout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const logoutMutation = useAdminLogout({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetAuthStatusQueryKey() });
        toast({ title: "Dalje e suksesshme", description: "Ju keni dalë nga paneli i adminit." });
        setLocation("/");
      },
      onError: () => {
        toast({ title: "Gabim", description: "Ndodhi një problem gjatë daljes.", variant: "destructive" });
      }
    }
  });

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const navLinks = [
    { href: "/admin", label: "Përmbledhja", icon: LayoutDashboard },
    { href: "/admin/rregullat", label: "Rregullat", icon: BookOpen },
    { href: "/admin/njoftime", label: "Njoftime", icon: Bell },
    { href: "/admin/raportime", label: "Raportime", icon: FlagTriangleRight },
    { href: "/admin/makina", label: "Makina", icon: CarFront },
    { href: "/admin/shtepi", label: "Shtëpi", icon: Home },
    { href: "/admin/pune", label: "Punë", icon: Briefcase },
    { href: "/admin/server", label: "Statusi i Serverit", icon: Server },
  ];

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-background">
      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between p-4 border-b border-white/10 bg-card">
        <span className="font-bold text-xl text-primary">ALPHA ADMIN</span>
        <Button variant="ghost" size="icon" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
          {mobileMenuOpen ? <X /> : <Menu />}
        </Button>
      </div>

      {/* Sidebar */}
      <aside className={`
        ${mobileMenuOpen ? 'flex' : 'hidden'} 
        md:flex flex-col w-full md:w-64 border-r border-white/10 bg-card shrink-0
      `}>
        <div className="p-6 hidden md:block">
          <span className="font-bold text-2xl tracking-tight text-white">
            ALPHA<span className="text-primary">ADMIN</span>
          </span>
        </div>
        
        <nav className="flex-1 py-4 flex flex-col gap-1 px-3">
          {navLinks.map((link) => {
            const Icon = link.icon;
            const isActive = location === link.href || (link.href !== "/admin" && location.startsWith(link.href));
            
            return (
              <Link 
                key={link.href} 
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`
                  flex items-center gap-3 px-4 py-3 rounded-md transition-colors text-sm font-medium
                  ${isActive 
                    ? 'bg-primary/10 text-primary border border-primary/20' 
                    : 'text-muted-foreground hover:bg-white/5 hover:text-white'}
                `}
              >
                <Icon className="h-5 w-5" />
                {link.label}
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-white/10">
          <Button 
            variant="ghost" 
            className="w-full justify-start text-muted-foreground hover:text-destructive hover:bg-destructive/10"
            onClick={handleLogout}
            disabled={logoutMutation.isPending}
          >
            <LogOut className="mr-2 h-5 w-5" />
            Dil (Logout)
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <div className="p-6 md:p-8 max-w-7xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
}
