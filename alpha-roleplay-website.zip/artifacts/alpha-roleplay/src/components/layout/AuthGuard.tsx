import { useGetAuthStatus, getGetAuthStatusQueryKey } from "@workspace/api-client-react";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { Loader2 } from "lucide-react";

export function AuthGuard({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const { data: authStatus, isLoading } = useGetAuthStatus({
    query: { queryKey: getGetAuthStatusQueryKey() }
  });

  useEffect(() => {
    if (!isLoading && authStatus && !authStatus.authenticated) {
      setLocation("/admin/login");
    }
  }, [authStatus, isLoading, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  if (!authStatus?.authenticated) {
    return null; // Will redirect via useEffect
  }

  return <>{children}</>;
}
