import { Link } from "wouter";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

const DISCORD_URL = "https://discord.gg/alpharpal";

export function PageLayout({ children }: { children: React.ReactNode }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { href: "/", label: "Ballina" },
    { href: "/rregullat", label: "Rregullat" },
    { href: "/njoftime", label: "Njoftime" },
    { href: "/makina-vip", label: "Makina VIP" },
    { href: "/makina-ultra-vip", label: "Ultra VIP" },
    { href: "/shtepi", label: "Shtëpi" },
    { href: "/pune", label: "Punë" },
    { href: "/raportime", label: "Raportime" },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background selection:bg-primary selection:text-white">
      <header className="sticky top-0 z-50 w-full border-b border-white/10 bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 group">
            <img
              src="/images/logo.webp"
              alt="Alpha Roleplay"
              className="h-10 w-10 object-contain drop-shadow-[0_0_12px_rgba(239,68,68,0.5)] group-hover:drop-shadow-[0_0_18px_rgba(239,68,68,0.85)] transition-all"
            />
            <span className="text-2xl font-black tracking-tighter uppercase italic text-white group-hover:text-primary transition-colors hidden sm:inline">
              Alpha<span className="text-primary group-hover:text-white transition-colors">RP</span>
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-6">
            {navLinks.map((link) => (
              <Link 
                key={link.href} 
                href={link.href}
                className="text-sm font-medium text-muted-foreground hover:text-white transition-colors uppercase tracking-wide"
              >
                {link.label}
              </Link>
            ))}
            <a
              href={DISCORD_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-md bg-[#5865F2] hover:bg-[#4752c4] text-white px-3 py-1.5 text-sm font-bold uppercase tracking-wide transition-colors shadow-[0_0_18px_rgba(88,101,242,0.45)]"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 fill-current" aria-hidden="true">
                <path d="M20.317 4.369A19.79 19.79 0 0 0 16.558 3a14.66 14.66 0 0 0-.69 1.42 18.27 18.27 0 0 0-5.736 0A14.16 14.16 0 0 0 9.44 3a19.79 19.79 0 0 0-3.76 1.37C2.04 9.84 1.07 15.16 1.55 20.4a19.92 19.92 0 0 0 6.04 3.06c.49-.66.93-1.36 1.3-2.1a13 13 0 0 1-2.05-.98c.17-.13.34-.26.5-.4a14.21 14.21 0 0 0 12.22 0c.17.14.34.27.5.4-.65.39-1.34.72-2.05.98.38.74.81 1.44 1.3 2.1a19.9 19.9 0 0 0 6.04-3.06c.57-6.07-.95-11.34-3.93-16.03ZM8.52 16.36c-1.2 0-2.18-1.1-2.18-2.45s.96-2.45 2.18-2.45 2.2 1.11 2.18 2.45c0 1.35-.96 2.45-2.18 2.45Zm6.96 0c-1.2 0-2.18-1.1-2.18-2.45s.96-2.45 2.18-2.45 2.2 1.11 2.18 2.45c0 1.35-.96 2.45-2.18 2.45Z" />
              </svg>
              Discord
            </a>
          </nav>

          {/* Mobile Menu Toggle */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden text-white"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>

        {/* Mobile Nav */}
        {mobileMenuOpen && (
          <div className="md:hidden border-b border-white/10 bg-background px-4 py-4 space-y-4">
            {navLinks.map((link) => (
              <Link 
                key={link.href} 
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="block text-lg font-medium text-muted-foreground hover:text-white transition-colors uppercase tracking-wide"
              >
                {link.label}
              </Link>
            ))}
            <a
              href={DISCORD_URL}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setMobileMenuOpen(false)}
              className="block w-full text-center rounded-md bg-[#5865F2] hover:bg-[#4752c4] text-white px-4 py-2 text-base font-bold uppercase tracking-wide transition-colors"
            >
              Bashkohu në Discord
            </a>
          </div>
        )}
      </header>

      <main className="flex-1">
        {children}
      </main>

      <footer className="border-t border-white/10 py-10 mt-12 bg-black/50">
        <div className="container mx-auto px-4 flex flex-col items-center text-center gap-5">
          <img
            src="/images/logo.webp"
            alt="Alpha Roleplay"
            className="h-16 w-16 object-contain drop-shadow-[0_0_18px_rgba(239,68,68,0.6)]"
          />
          <a
            href={DISCORD_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-md bg-[#5865F2] hover:bg-[#4752c4] text-white px-5 py-2.5 text-sm font-bold uppercase tracking-wide transition-colors shadow-[0_0_24px_rgba(88,101,242,0.5)]"
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4 fill-current" aria-hidden="true">
              <path d="M20.317 4.369A19.79 19.79 0 0 0 16.558 3a14.66 14.66 0 0 0-.69 1.42 18.27 18.27 0 0 0-5.736 0A14.16 14.16 0 0 0 9.44 3a19.79 19.79 0 0 0-3.76 1.37C2.04 9.84 1.07 15.16 1.55 20.4a19.92 19.92 0 0 0 6.04 3.06c.49-.66.93-1.36 1.3-2.1a13 13 0 0 1-2.05-.98c.17-.13.34-.26.5-.4a14.21 14.21 0 0 0 12.22 0c.17.14.34.27.5.4-.65.39-1.34.72-2.05.98.38.74.81 1.44 1.3 2.1a19.9 19.9 0 0 0 6.04-3.06c.57-6.07-.95-11.34-3.93-16.03ZM8.52 16.36c-1.2 0-2.18-1.1-2.18-2.45s.96-2.45 2.18-2.45 2.2 1.11 2.18 2.45c0 1.35-.96 2.45-2.18 2.45Zm6.96 0c-1.2 0-2.18-1.1-2.18-2.45s.96-2.45 2.18-2.45 2.2 1.11 2.18 2.45c0 1.35-.96 2.45-2.18 2.45Z" />
            </svg>
            Bashkohu në Discord
          </a>
          <p className="text-muted-foreground text-sm">
            &copy; {new Date().getFullYear()} Alpha Roleplay. Të gjitha të drejtat e rezervuara.
          </p>
          <div className="flex justify-center gap-4">
            <Link href="/admin/login" className="text-xs text-muted-foreground/50 hover:text-primary transition-colors">
              Admin Panel
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
