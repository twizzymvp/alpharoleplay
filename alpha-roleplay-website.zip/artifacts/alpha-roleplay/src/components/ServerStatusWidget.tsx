import {
  useGetServerStatus,
  getGetServerStatusQueryKey,
} from "@workspace/api-client-react";
import { motion } from "framer-motion";
import { Users, Circle } from "lucide-react";

export function ServerStatusWidget() {
  const { data, isLoading } = useGetServerStatus({
    query: {
      queryKey: getGetServerStatusQueryKey(),
      refetchInterval: 30000,
    },
  });

  if (isLoading || !data || !data.isVisible) return null;

  const online = data.isOnline;
  const pct = data.maxPlayers
    ? Math.min(100, Math.round((data.playersOnline / data.maxPlayers) * 100))
    : 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.4 }}
      className="mt-8 inline-flex flex-col items-center gap-3 rounded-2xl border border-white/15 bg-black/60 backdrop-blur-md px-5 py-4 shadow-[0_0_30px_rgba(0,0,0,0.5)]"
    >
      <div className="flex items-center gap-3">
        <span className="relative flex h-3 w-3">
          {online && (
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
          )}
          <Circle
            className={`relative h-3 w-3 ${
              online ? "fill-emerald-500 text-emerald-500" : "fill-red-500 text-red-500"
            }`}
          />
        </span>
        <span className="font-bold uppercase tracking-widest text-sm text-white">
          {data.serverName}
        </span>
        <span
          className={`text-xs uppercase font-bold tracking-wider ${
            online ? "text-emerald-400" : "text-red-400"
          }`}
        >
          {online ? "Online" : "Offline"}
        </span>
      </div>

      <div className="flex items-center gap-3 w-full">
        <Users className="h-4 w-4 text-primary" />
        <div className="flex-1 h-2 rounded-full bg-white/10 overflow-hidden min-w-[140px]">
          <div
            className="h-full bg-gradient-to-r from-primary to-purple-600 transition-all duration-500"
            style={{ width: `${pct}%` }}
          />
        </div>
        <span className="text-sm font-mono text-white tabular-nums">
          {data.playersOnline}/{data.maxPlayers}
        </span>
      </div>

      {data.message && (
        <p className="text-xs text-white/70 text-center max-w-xs">
          {data.message}
        </p>
      )}
    </motion.div>
  );
}
