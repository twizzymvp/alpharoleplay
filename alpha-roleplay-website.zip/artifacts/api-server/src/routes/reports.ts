import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, reportsTable } from "@workspace/db";
import {
  SubmitReportBody,
  UpdateReportBody,
  UpdateReportParams,
  DeleteReportParams,
} from "@workspace/api-zod";
import { requireAdmin } from "../middlewares/auth";
import { sendDiscord } from "../lib/discord";

const router: IRouter = Router();

router.get("/reports", requireAdmin, async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(reportsTable)
    .orderBy(desc(reportsTable.createdAt));
  res.json(rows);
});

router.post("/reports", async (req, res): Promise<void> => {
  const parsed = SubmitReportBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [row] = await db
    .insert(reportsTable)
    .values({ ...parsed.data, status: "open" })
    .returning();

  await sendDiscord("REPORTS", {
    embeds: [
      {
        title: "Raport i Ri",
        color: 0xef4444,
        fields: [
          { name: "Emri", value: row!.name, inline: true },
          { name: "ID në server", value: row!.serverId, inline: true },
          { name: "Përshkrimi", value: row!.description.slice(0, 1024) },
          { name: "ID Raporti", value: `#${row!.id}`, inline: true },
          { name: "Statusi", value: "I hapur", inline: true },
        ],
        timestamp: new Date().toISOString(),
        footer: { text: "Alpha Roleplay" },
      },
    ],
  });

  res.status(201).json(row);
});

router.patch("/reports/:id", requireAdmin, async (req, res): Promise<void> => {
  const params = UpdateReportParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = UpdateReportBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const [row] = await db
    .update(reportsTable)
    .set(body.data)
    .where(eq(reportsTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Raporti nuk u gjet" });
    return;
  }
  res.json(row);
});

router.delete("/reports/:id", requireAdmin, async (req, res): Promise<void> => {
  const params = DeleteReportParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db
    .delete(reportsTable)
    .where(eq(reportsTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Raporti nuk u gjet" });
    return;
  }
  res.sendStatus(204);
});

export default router;
