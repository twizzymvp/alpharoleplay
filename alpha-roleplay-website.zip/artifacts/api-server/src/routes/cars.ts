import { Router, type IRouter } from "express";
import { eq, desc, and } from "drizzle-orm";
import { db, carsTable } from "@workspace/db";
import {
  ListCarsQueryParams,
  CreateCarBody,
  UpdateCarBody,
  UpdateCarParams,
  DeleteCarParams,
  BuyCarParams,
  BuyCarBody,
} from "@workspace/api-zod";
import { requireAdmin } from "../middlewares/auth";
import { sendDiscord } from "../lib/discord";

const router: IRouter = Router();

router.get("/cars", async (req, res): Promise<void> => {
  const q = ListCarsQueryParams.safeParse(req.query);
  if (!q.success) {
    res.status(400).json({ error: q.error.message });
    return;
  }
  const where = q.data.tier ? eq(carsTable.tier, q.data.tier) : undefined;
  const rows = where
    ? await db.select().from(carsTable).where(where).orderBy(desc(carsTable.createdAt))
    : await db.select().from(carsTable).orderBy(desc(carsTable.createdAt));
  res.json(rows);
});

router.post("/cars", requireAdmin, async (req, res): Promise<void> => {
  const parsed = CreateCarBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [row] = await db.insert(carsTable).values(parsed.data).returning();
  res.status(201).json(row);
});

router.patch("/cars/:id", requireAdmin, async (req, res): Promise<void> => {
  const params = UpdateCarParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = UpdateCarBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const [row] = await db
    .update(carsTable)
    .set(body.data)
    .where(eq(carsTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Makina nuk u gjet" });
    return;
  }
  res.json(row);
});

router.delete("/cars/:id", requireAdmin, async (req, res): Promise<void> => {
  const params = DeleteCarParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db
    .delete(carsTable)
    .where(eq(carsTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Makina nuk u gjet" });
    return;
  }
  res.sendStatus(204);
});

router.post("/cars/:id/buy", async (req, res): Promise<void> => {
  const params = BuyCarParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = BuyCarBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [car] = await db
    .select()
    .from(carsTable)
    .where(eq(carsTable.id, params.data.id));
  if (!car) {
    res.status(404).json({ error: "Makina nuk u gjet" });
    return;
  }

  const isUltra = car.tier === "ultra_vip";
  const tierLabel = isUltra ? "Ultra VIP" : "VIP";
  const color = isUltra ? 0xa855f7 : 0xfbbf24;

  await sendDiscord(isUltra ? "ULTRA_VIP" : "VIP", {
    embeds: [
      {
        title: `Blerje e re — Makinë ${tierLabel}`,
        description:
          "Klienti pas blerjes është i lutur të hapë një ticket në Discord për finalizim.",
        color,
        fields: [
          { name: "Makina", value: car.name, inline: true },
          { name: "Çmimi", value: car.price, inline: true },
          { name: "Tier", value: tierLabel, inline: true },
          { name: "Blerësi / Familja", value: body.data.buyerName, inline: true },
          ...(body.data.contact
            ? [{ name: "Discord", value: body.data.contact, inline: true }]
            : []),
          ...(body.data.notes
            ? [{ name: "Detaje shtesë", value: body.data.notes.slice(0, 1024) }]
            : []),
        ],
        ...(car.imageUrl ? { thumbnail: { url: car.imageUrl } } : {}),
        timestamp: new Date().toISOString(),
        footer: { text: "Alpha Roleplay — Hap ticket në Discord pas blerjes" },
      },
    ],
  });

  res.status(201).json({
    success: true,
    message:
      "Blerja u dërgua. Pas blerjes, hap një ticket në Discord që adminat ta finalizojnë.",
  });
});

export default router;
