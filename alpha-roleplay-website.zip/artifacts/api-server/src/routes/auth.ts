import { Router, type IRouter } from "express";
import { AdminLoginBody } from "@workspace/api-zod";
import { ADMIN_COOKIE, getAdminUsername } from "../middlewares/auth";

const router: IRouter = Router();

const ADMIN_USERNAME = process.env["ADMIN_USERNAME"] ?? "admin";
const ADMIN_PASSWORD = process.env["ADMIN_PASSWORD"] ?? "alpharp2026";

const cookieOptions = {
  httpOnly: true,
  signed: true,
  sameSite: "lax" as const,
  secure: false,
  maxAge: 1000 * 60 * 60 * 24 * 30, // 30 days
  path: "/",
};

router.post("/auth/login", (req, res): void => {
  const parsed = AdminLoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Të dhëna jovalide" });
    return;
  }

  const { username, password } = parsed.data;
  if (username !== ADMIN_USERNAME || password !== ADMIN_PASSWORD) {
    res.status(401).json({ error: "Username ose password gabim" });
    return;
  }

  res.cookie(ADMIN_COOKIE, username, cookieOptions);
  res.json({ authenticated: true, username });
});

router.post("/auth/logout", (_req, res): void => {
  res.clearCookie(ADMIN_COOKIE, { path: "/" });
  res.json({ authenticated: false, username: null });
});

router.get("/auth/me", (req, res): void => {
  const username = getAdminUsername(req);
  if (username) {
    res.json({ authenticated: true, username });
  } else {
    res.json({ authenticated: false, username: null });
  }
});

export default router;
