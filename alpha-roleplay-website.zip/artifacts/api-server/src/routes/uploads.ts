import { Router, type IRouter } from "express";
import multer from "multer";
import path from "node:path";
import fs from "node:fs";
import crypto from "node:crypto";
import { requireAdmin } from "../middlewares/auth";

const router: IRouter = Router();

const UPLOAD_DIR = path.resolve(process.cwd(), "uploads");
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

const ALLOWED_MIME = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
]);

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase().slice(0, 5) || ".bin";
    const id = crypto.randomBytes(12).toString("hex");
    cb(null, `${Date.now()}-${id}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 8 * 1024 * 1024 }, // 8MB
  fileFilter: (_req, file, cb) => {
    if (!ALLOWED_MIME.has(file.mimetype)) {
      cb(new Error("Lloji i skedarit nuk pranohet (vetëm imazhe)"));
      return;
    }
    cb(null, true);
  },
});

router.post("/upload", requireAdmin, upload.single("file"), (req, res) => {
  if (!req.file) {
    res.status(400).json({ error: "Asnjë skedar i ngarkuar" });
    return;
  }
  const publicHost =
    (req.headers["x-forwarded-host"] as string | undefined) || req.headers.host;
  const proto =
    (req.headers["x-forwarded-proto"] as string | undefined) || req.protocol;
  const base = publicHost ? `${proto}://${publicHost}` : "";
  const url = `/api/uploads/${req.file.filename}`;
  res.status(201).json({
    url,
    absoluteUrl: base ? `${base}${url}` : url,
    filename: req.file.filename,
    size: req.file.size,
  });
});

export default router;
export { UPLOAD_DIR };
