import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, jobsTable } from "@workspace/db";
import {
  CreateJobBody,
  UpdateJobBody,
  UpdateJobParams,
  DeleteJobParams,
  ApplyJobParams,
  ApplyJobBody,
} from "@workspace/api-zod";
import { requireAdmin } from "../middlewares/auth";
import { sendDiscord } from "../lib/discord";

const router: IRouter = Router();

router.get("/jobs", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(jobsTable)
    .orderBy(desc(jobsTable.createdAt));
  res.json(rows);
});

router.post("/jobs", requireAdmin, async (req, res): Promise<void> => {
  const parsed = CreateJobBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [row] = await db.insert(jobsTable).values(parsed.data).returning();
  res.status(201).json(row);
});

router.patch("/jobs/:id", requireAdmin, async (req, res): Promise<void> => {
  const params = UpdateJobParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = UpdateJobBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const [row] = await db
    .update(jobsTable)
    .set(body.data)
    .where(eq(jobsTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Puna nuk u gjet" });
    return;
  }
  res.json(row);
});

router.delete("/jobs/:id", requireAdmin, async (req, res): Promise<void> => {
  const params = DeleteJobParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db
    .delete(jobsTable)
    .where(eq(jobsTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Puna nuk u gjet" });
    return;
  }
  res.sendStatus(204);
});

router.post("/jobs/:id/apply", async (req, res): Promise<void> => {
  const params = ApplyJobParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = ApplyJobBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [job] = await db
    .select()
    .from(jobsTable)
    .where(eq(jobsTable.id, params.data.id));
  if (!job) {
    res.status(404).json({ error: "Puna nuk u gjet" });
    return;
  }

  await sendDiscord("JOBS", {
    embeds: [
      {
        title: "Blerje e re — Punë për Familje",
        description:
          "Klienti pas blerjes është i lutur të hapë një ticket në Discord për finalizim.",
        color: 0x3b82f6,
        fields: [
          { name: "Puna", value: job.name, inline: true },
          { name: "Çmimi", value: job.price, inline: true },
          { name: "Blerësi / Familja", value: body.data.buyerName, inline: true },
          ...(body.data.contact
            ? [{ name: "Discord", value: body.data.contact, inline: true }]
            : []),
          ...(body.data.notes
            ? [{ name: "Detajet e blerjes", value: body.data.notes.slice(0, 1024) }]
            : []),
        ],
        ...(job.imageUrl ? { thumbnail: { url: job.imageUrl } } : {}),
        timestamp: new Date().toISOString(),
        footer: { text: "Alpha Roleplay — Hap ticket në Discord pas blerjes" },
      },
    ],
  });

  res.status(201).json({
    success: true,
    message:
      "Blerja u dërgua. Pas blerjes, hap një ticket në Discord që adminat ta finalizojnë.",
  });
});

export default router;
