import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, rulesTable } from "@workspace/db";
import {
  CreateRuleBody,
  UpdateRuleBody,
  UpdateRuleParams,
  DeleteRuleParams,
} from "@workspace/api-zod";
import { requireAdmin } from "../middlewares/auth";

const router: IRouter = Router();

router.get("/rules", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(rulesTable)
    .orderBy(rulesTable.category, rulesTable.id);
  res.json(rows);
});

router.post("/rules", requireAdmin, async (req, res): Promise<void> => {
  const parsed = CreateRuleBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [row] = await db.insert(rulesTable).values(parsed.data).returning();
  res.status(201).json(row);
});

router.patch("/rules/:id", requireAdmin, async (req, res): Promise<void> => {
  const params = UpdateRuleParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = UpdateRuleBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const [row] = await db
    .update(rulesTable)
    .set(body.data)
    .where(eq(rulesTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Rregulli nuk u gjet" });
    return;
  }
  res.json(row);
});

router.delete("/rules/:id", requireAdmin, async (req, res): Promise<void> => {
  const params = DeleteRuleParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db
    .delete(rulesTable)
    .where(eq(rulesTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Rregulli nuk u gjet" });
    return;
  }
  res.sendStatus(204);
});

export default router;
