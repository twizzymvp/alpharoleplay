import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import rulesRouter from "./rules";
import announcementsRouter from "./announcements";
import reportsRouter from "./reports";
import carsRouter from "./cars";
import housesRouter from "./houses";
import jobsRouter from "./jobs";
import dashboardRouter from "./dashboard";
import uploadsRouter from "./uploads";
import serverStatusRouter from "./server-status";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(rulesRouter);
router.use(announcementsRouter);
router.use(reportsRouter);
router.use(carsRouter);
router.use(housesRouter);
router.use(jobsRouter);
router.use(dashboardRouter);
router.use(uploadsRouter);
router.use(serverStatusRouter);

export default router;
