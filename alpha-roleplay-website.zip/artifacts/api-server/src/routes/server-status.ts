import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, serverStatusTable } from "@workspace/db";
import { UpdateServerStatusBody } from "@workspace/api-zod";
import { requireAdmin } from "../middlewares/auth";

const router: IRouter = Router();

const ROW_ID = 1;

async function ensureRow() {
  const existing = await db
    .select()
    .from(serverStatusTable)
    .where(eq(serverStatusTable.id, ROW_ID))
    .limit(1);
  if (existing.length > 0) return existing[0]!;
  const [created] = await db
    .insert(serverStatusTable)
    .values({
      id: ROW_ID,
      isVisible: true,
      isOnline: true,
      playersOnline: 0,
      maxPlayers: 64,
      serverName: "Alpha Roleplay",
      message: null,
    })
    .returning();
  return created!;
}

router.get("/server-status", async (_req, res): Promise<void> => {
  const row = await ensureRow();
  res.json(row);
});

router.put(
  "/server-status",
  requireAdmin,
  async (req, res): Promise<void> => {
    const parsed = UpdateServerStatusBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }
    await ensureRow();
    const [row] = await db
      .update(serverStatusTable)
      .set(parsed.data)
      .where(eq(serverStatusTable.id, ROW_ID))
      .returning();
    res.json(row);
  },
);

export default router;
