import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, housesTable } from "@workspace/db";
import {
  CreateHouseBody,
  UpdateHouseBody,
  UpdateHouseParams,
  DeleteHouseParams,
  BuyHouseParams,
  BuyHouseBody,
} from "@workspace/api-zod";
import { requireAdmin } from "../middlewares/auth";
import { sendDiscord } from "../lib/discord";

const router: IRouter = Router();

router.get("/houses", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(housesTable)
    .orderBy(desc(housesTable.createdAt));
  res.json(rows);
});

router.post("/houses", requireAdmin, async (req, res): Promise<void> => {
  const parsed = CreateHouseBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [row] = await db.insert(housesTable).values(parsed.data).returning();
  res.status(201).json(row);
});

router.patch("/houses/:id", requireAdmin, async (req, res): Promise<void> => {
  const params = UpdateHouseParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = UpdateHouseBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const [row] = await db
    .update(housesTable)
    .set(body.data)
    .where(eq(housesTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Shtëpia nuk u gjet" });
    return;
  }
  res.json(row);
});

router.delete("/houses/:id", requireAdmin, async (req, res): Promise<void> => {
  const params = DeleteHouseParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db
    .delete(housesTable)
    .where(eq(housesTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Shtëpia nuk u gjet" });
    return;
  }
  res.sendStatus(204);
});

router.post("/houses/:id/buy", async (req, res): Promise<void> => {
  const params = BuyHouseParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = BuyHouseBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [house] = await db
    .select()
    .from(housesTable)
    .where(eq(housesTable.id, params.data.id));
  if (!house) {
    res.status(404).json({ error: "Shtëpia nuk u gjet" });
    return;
  }

  await sendDiscord("HOUSES", {
    embeds: [
      {
        title: "Blerje e re — Shtëpi për Familje",
        description:
          "Klienti pas blerjes është i lutur të hapë një ticket në Discord për finalizim.",
        color: 0x10b981,
        fields: [
          { name: "Shtëpia", value: house.name, inline: true },
          { name: "Lokacioni", value: house.location, inline: true },
          { name: "Çmimi", value: house.price, inline: true },
          { name: "Kapaciteti", value: String(house.capacity), inline: true },
          { name: "Blerësi / Familja", value: body.data.buyerName, inline: true },
          ...(body.data.contact
            ? [{ name: "Discord", value: body.data.contact, inline: true }]
            : []),
          ...(body.data.notes
            ? [{ name: "Detaje shtesë", value: body.data.notes.slice(0, 1024) }]
            : []),
        ],
        ...(house.imageUrl ? { thumbnail: { url: house.imageUrl } } : {}),
        timestamp: new Date().toISOString(),
        footer: { text: "Alpha Roleplay — Hap ticket në Discord pas blerjes" },
      },
    ],
  });

  res.status(201).json({
    success: true,
    message:
      "Blerja u dërgua. Pas blerjes, hap një ticket në Discord që adminat ta finalizojnë.",
  });
});

export default router;
