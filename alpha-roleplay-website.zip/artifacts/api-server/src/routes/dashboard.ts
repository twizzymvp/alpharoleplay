import { Router, type IRouter } from "express";
import { sql, eq } from "drizzle-orm";
import {
  db,
  rulesTable,
  announcementsTable,
  reportsTable,
  carsTable,
  housesTable,
  jobsTable,
} from "@workspace/db";
import { requireAdmin } from "../middlewares/auth";

const router: IRouter = Router();

router.get(
  "/dashboard/stats",
  requireAdmin,
  async (_req, res): Promise<void> => {
    const [
      [rules],
      [announcements],
      [reports],
      [openReports],
      [cars],
      [houses],
      [jobs],
    ] = await Promise.all([
      db.select({ count: sql<number>`count(*)::int` }).from(rulesTable),
      db.select({ count: sql<number>`count(*)::int` }).from(announcementsTable),
      db.select({ count: sql<number>`count(*)::int` }).from(reportsTable),
      db
        .select({ count: sql<number>`count(*)::int` })
        .from(reportsTable)
        .where(eq(reportsTable.status, "open")),
      db.select({ count: sql<number>`count(*)::int` }).from(carsTable),
      db.select({ count: sql<number>`count(*)::int` }).from(housesTable),
      db.select({ count: sql<number>`count(*)::int` }).from(jobsTable),
    ]);

    res.json({
      rules: rules?.count ?? 0,
      announcements: announcements?.count ?? 0,
      reports: reports?.count ?? 0,
      openReports: openReports?.count ?? 0,
      cars: cars?.count ?? 0,
      houses: houses?.count ?? 0,
      jobs: jobs?.count ?? 0,
    });
  },
);

export default router;
