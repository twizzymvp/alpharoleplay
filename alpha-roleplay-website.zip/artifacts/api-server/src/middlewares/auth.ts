import type { Request, Response, NextFunction } from "express";

export const ADMIN_COOKIE = "alpha_admin";

export function getAdminUsername(req: Request): string | null {
  const signed = req.signedCookies?.[ADMIN_COOKIE];
  if (typeof signed === "string" && signed.length > 0) {
    return signed;
  }
  return null;
}

export function requireAdmin(
  req: Request,
  res: Response,
  next: NextFunction,
): void {
  const username = getAdminUsername(req);
  if (!username) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  next();
}
