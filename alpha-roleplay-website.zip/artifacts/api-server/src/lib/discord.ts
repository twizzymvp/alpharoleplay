import { logger } from "./logger";

type WebhookKey =
  | "REPORTS"
  | "VIP"
  | "ULTRA_VIP"
  | "HOUSES"
  | "JOBS";

const WEBHOOK_ENV: Record<WebhookKey, string> = {
  REPORTS: "DISCORD_WEBHOOK_REPORTS",
  VIP: "DISCORD_WEBHOOK_VIP",
  ULTRA_VIP: "DISCORD_WEBHOOK_ULTRA_VIP",
  HOUSES: "DISCORD_WEBHOOK_HOUSES",
  JOBS: "DISCORD_WEBHOOK_JOBS",
};

export interface DiscordEmbedField {
  name: string;
  value: string;
  inline?: boolean;
}

export interface DiscordEmbed {
  title?: string;
  description?: string;
  color?: number;
  fields?: DiscordEmbedField[];
  image?: { url: string };
  thumbnail?: { url: string };
  timestamp?: string;
  footer?: { text: string };
}

export interface DiscordPayload {
  content?: string;
  username?: string;
  embeds?: DiscordEmbed[];
}

export async function sendDiscord(
  key: WebhookKey,
  payload: DiscordPayload,
): Promise<void> {
  const envVar = WEBHOOK_ENV[key];
  const url = process.env[envVar];

  if (!url) {
    logger.warn({ key, envVar }, "Discord webhook URL not configured; skipping");
    return;
  }

  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: payload.username ?? "Alpha Roleplay",
        ...payload,
      }),
    });

    if (!res.ok) {
      const text = await res.text().catch(() => "");
      logger.error(
        { key, status: res.status, body: text.slice(0, 500) },
        "Discord webhook failed",
      );
    }
  } catch (err) {
    logger.error({ err, key }, "Discord webhook error");
  }
}
